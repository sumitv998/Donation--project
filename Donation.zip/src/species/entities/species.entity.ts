import { ApiProperty } from "@nestjs/swagger";
import { UsersCorporates } from "../../users/entities/usersCorporate.entity";
import { favouriteSpecies } from "src/favourite/entities/favSpecies.entity";
import { Projects } from "../../projects/entities/project.entity";
import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import { AssetSpecies } from "./assetsSpecies.entity";
import { paymentTransactions } from "src/payments/entities/payments.entity";

@Entity()
export class Species {
  @PrimaryGeneratedColumn("uuid")
  public id: string;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  speciesName: string;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  speciesNameScientific: string;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  category: CATEGORY;

  @Column({ type: "varchar", nullable: true })
  geographicRegion: GEOGRAPHICREGION;

  @Column({ type: "varchar", nullable: true })
  habitateType: HABITATETYPE;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  overview: string;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  speciesDetails: string;

  @OneToMany(() => Projects, (project: Projects) => project.species)
  project: Projects;

  @ApiProperty()
  @Column({ default: 0, type: "int8", nullable: true })
  likesCount: number;

  @ApiProperty()
  @OneToMany(() => AssetSpecies, (assets: AssetSpecies) => assets.species)
  assets: AssetSpecies[];

  @ApiProperty()
  @OneToMany(
    () => favouriteSpecies,
    (species: favouriteSpecies) => species.species
  )
  favSpecies: favouriteSpecies[];

  @ApiProperty()
  @OneToMany(
    () => paymentTransactions,
    (speciesTransaction: paymentTransactions) => speciesTransaction.species
  )
  speciesTransaction: paymentTransactions[];

  @Column({ type: "boolean", default: false })
  isActive: boolean;

  // @Column({nullable: true, default: 0})
  // favCount: number;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}

export enum HABITATETYPE {
  ALL = "All",
  Forest = "Forest",
  Savanna = "Savanna",
  Shrubland = "Shrubland",
  Grasslands = "Grasslands",
  Wetlands = "Wetlands",
  RockyAreas = "Rocky Areas",
  CavesAndSubterranean = "Caves & Subterranean",
  Desert = "Desert",
  MarineNeritic = "Marine Neritic",
  MarineOceanic = "Marine Oceanic",
  MarineDeepOceanFloor = "Marine Deep Ocean Floor",
  MarineIntertidal = "Marine Intertidal",
  MarineCoastal = "Marine Coastal/Supratidal",
}

export enum CATEGORY {
  ALL = "All",
  Critically_Endangered = "Critically Endangered",
  Endangered = "Endangered",
  Vulnerable = "Vulnerable",
}

export enum GEOGRAPHICREGION {
  ALL = "All",
  Antarctic = "Antarctic",
  Caribbean_Islands = "Caribbean Islands",
  East_Asia = "East Asia",
  Europe = "Europe",
  Mesoamerica = "Mesoamerica",
  North_Africa = "North Africa",
  North_America = "North America",
  North_Asia = "North Asia",
  Oceania = "Oceania",
  South_America = "South America",
  South_And_Southea = "South and Southea..",
  Sub_Saharan_Africa = "Sub-Saharan Africa",
  West_And_Central_Asia = "West And Central Asia",
}
