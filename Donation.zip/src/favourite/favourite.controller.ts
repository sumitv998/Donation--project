import { Controller } from "@nestjs/common";

@Controller("favourite")
export class FavoriteController {}
