import { Module } from "@nestjs/common";
import { AdminService } from "./admin.service";
import { AdminController } from "./admin.controller";
import { JwtService } from "@nestjs/jwt";
import { TypeOrmModule } from "@nestjs/typeorm";
import { UsersCorporates } from "src/users/entities/usersCorporate.entity";
import { SendGridEmailService } from "src/services/sendgridEmail.service";
import { Species } from "src/species/entities/species.entity";
import { Projects } from "src/projects/entities/project.entity";
import { paymentTransactions } from "src/payments/entities/payments.entity";
import { NowPaymentService } from "src/payments/nowPayments.service";
import { TransactionService } from "src/payments/transaction.repo";
import { HttpModule } from "@nestjs/axios";
import { LatestCurrencyPrice } from "src/payments/entities/latestCurrencyPrice.entity";
import { SpeciesRepository } from "src/species/species.repository";
import { mailFormat } from "src/config/mailFormat";
import { paymentEmailReceipt } from "src/services/paymentEmailReceipt.service";

@Module({
  imports: [
    // JwtModule.register({
    //   secret: process.env.ADMIN_JWT_SECRET,
    //   signOptions: {
    //     expiresIn: "24h",
    //   },
    // }),
    HttpModule.register({ timeout: 5000, maxRedirects: 5 }),
    TypeOrmModule.forFeature([
      UsersCorporates,
      Species,
      Projects,
      paymentTransactions,
      LatestCurrencyPrice,
    ]),
  ],
  controllers: [AdminController],
  providers: [
    AdminService,
    SendGridEmailService,
    JwtService,
    NowPaymentService,
    TransactionService,
    SpeciesRepository,
    paymentEmailReceipt,
    mailFormat,
  ],
})
export class AdminModule {}
