import { ApiProperty } from "@nestjs/swagger";
import {
  IsArray,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from "class-validator";

export class StripeInvoiceDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  price_amount: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  pay_currency: string;

  @ApiProperty()
  @IsNumber()
  @IsOptional()
  _5wfAmount: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  products: Product[];
}

export class StripeInvoice5WFDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  pay_currency: string;

  @ApiProperty()
  @IsNumber()
  @IsNotEmpty()
  _5wfAmount: number;
}

export interface Product {
  name: string;
  productType: string;
  productId: string;
  amount: number;
}
