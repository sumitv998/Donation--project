import { IsEnum, IsNotEmpty, IsOptional, IsString } from "class-validator";
import {
  CATEGORY,
  GEOGRAPHICREGION,
  HABITATETYPE,
} from "../entities/species.entity";

export class CreateSpeciesDto {
  @IsOptional()
  coverImage: string;

  @IsString()
  @IsNotEmpty()
  speciesName: string;

  @IsString()
  @IsOptional()
  speciesNameScientific: string;

  @IsString()
  @IsNotEmpty()
  @IsEnum(CATEGORY)
  category: CATEGORY;

  @IsString()
  @IsNotEmpty()
  @IsEnum(GEOGRAPHICREGION)
  geographicRegion: GEOGRAPHICREGION;

  @IsString()
  @IsNotEmpty()
  @IsEnum(HABITATETYPE)
  habitateType: HABITATETYPE;

  @IsString()
  @IsOptional()
  overview: string;

  @IsString()
  @IsOptional()
  speciesDetails: string;

  @IsString()
  @IsOptional()
  speciesVideo: string;

  @IsOptional()
  images: [];

  @IsString()
  @IsOptional()
  speciesProfile: string;
}
