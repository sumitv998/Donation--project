import { ApiProperty } from "@nestjs/swagger";
import { Projects } from "src/projects/entities/project.entity";
import { UsersCorporates } from "src/users/entities/usersCorporate.entity";
import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from "typeorm";

@Entity()
export class favouriteProject {
  @PrimaryGeneratedColumn("uuid")
  public id: string;

  @ApiProperty()
  @Column({ default: false, type: "boolean", nullable: true })
  isFavourite: boolean;

  @ApiProperty()
  @Column({ default: false, type: "boolean", nullable: false })
  carts: boolean;

  @ApiProperty()
  @Column({ default: false, type: "boolean", nullable: true })
  isLiked: Boolean;

  @ManyToOne(
    () => UsersCorporates,
    (users: UsersCorporates) => users.favProject
  )
  @JoinColumn({ name: "userId" })
  user: UsersCorporates;

  @ManyToOne(() => Projects, (project: Projects) => project.favProject)
  @JoinColumn({ name: "projectId" })
  project: Projects;
}
