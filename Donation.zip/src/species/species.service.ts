import {
  BadRequestException,
  HttpException,
  HttpStatus,
  Injectable,
} from "@nestjs/common";
import { Repository } from "typeorm";
import { JwtService } from "@nestjs/jwt";
import { InjectRepository } from "@nestjs/typeorm";
import { Species } from "./entities/species.entity";
import { CreateSpeciesDto } from "./dto/createSpecies.dto";
import { AssetSpecies } from "./entities/assetsSpecies.entity";
import { S3Service } from "src/services/s3.service";

@Injectable()
export class SpeciesService {
  constructor(
    @InjectRepository(Species)
    private speciesRepository: Repository<Species>,

    @InjectRepository(AssetSpecies)
    private speciesAssetsRepository: Repository<AssetSpecies>,
    private s3service: S3Service,
    private jwtService: JwtService
  ) {}

  async createSpecies(
    createSpeciesDto: CreateSpeciesDto,
    req
  ): Promise<Species | any> {
    try {
      if (req.user.userRole == "Admin") {
        const {
          speciesProfile,
          coverImage,
          speciesName,
          speciesNameScientific,
          speciesDetails,
          speciesVideo,
          overview,
          category,
          geographicRegion,
          images,
          habitateType,
        } = createSpeciesDto;
        const species = await this.speciesRepository.create({
          speciesName,
          speciesNameScientific,
          speciesDetails,
          overview,
          category,
          geographicRegion,
          habitateType,
        });

        const data = await this.speciesRepository.save(species);
        if (!data) {
          throw new HttpException(
            "Please Provide species data!",
            HttpStatus.NOT_FOUND
          );
        }

        if (coverImage == null && coverImage == undefined) {
          coverImage == undefined;
        } else {
          let s3DataCoverImage: any = await this.s3service.uploadFile(
            coverImage[0]
          );
          await this.createAssest({
            species: data.id,
            url: s3DataCoverImage.Location,
            type: "coverImage",
          });
        }

        if (images == null && images == undefined) {
          images == undefined;
        } else {
          for (let j = 0; j < images.length; j++) {
            let s3Data: any = await this.s3service.uploadFile(images[j]);
            await this.createAssest({
              species: data.id,
              url: s3Data.Location,
              type: "images",
            });
          }
        }

        if (speciesProfile == null && speciesProfile == undefined) {
          speciesProfile == undefined;
        } else {
          let s3DataspeciesProfile: any = await this.s3service.uploadFile(
            speciesProfile[0]
          );
          await this.createAssest({
            species: data.id,
            url: s3DataspeciesProfile.Location,
            type: "speciesProfile",
          });
        }

        if (speciesVideo == null && speciesVideo == undefined) {
          speciesVideo == undefined;
        } else {
          let s3DataSpeciesVideo: any = await this.s3service.uploadFile(
            speciesVideo[0]
          );
          await this.createAssest({
            species: data.id,
            url: s3DataSpeciesVideo.Location,
            type: "speciesVideo",
          });
        }
        return {
          success: true,
          message: "Your Species was create Successfully",
        };
      } else {
        throw new HttpException(
          "Only Admin can create Species!",
          HttpStatus.BAD_REQUEST
        );
      }
    } catch (error) {
      throw new BadRequestException(error.response);
    }
  }

  async createAssest(body): Promise<AssetSpecies | any> {
    const q = await this.speciesAssetsRepository.create(body);
    await this.speciesAssetsRepository.save(q);
  }

  // async uploadSpeciesProfile(file, id, req: Request) {
  //   const jwt = req.cookies["token"];
  //   if (!jwt) {
  //     throw new BadRequestException("please login");
  //   }
  //   await this.jwtService.verifyAsync(jwt, {
  //     secret: process.env.ADMIN_JWT_SECRET,
  //   });
  //   const speciesId = await this.speciesRepository.findOne({
  //     where: { id: id },
  //   });
  //   if(!speciesId){
  //     throw new HttpException("Species Id is not valid", HttpStatus.NOT_FOUND);
  //   }

  //   const s3Image: any = await this.s3service.uploadFile(file);
  //   await this.createAssest({
  //     species: speciesId.id,
  //     url: s3Image.Location,
  //     type: "speciesProfile",
  //   });
  //   return { succes: 200, message: "species profile uploaded successfully" };
  // }

  async getAllSpecies(req):Promise<Species | any> {
    try {
      if (req.user.userRole == "Admin") {
        const data = await this.speciesRepository.find();
        return {
          status: true,
          species: data
        }
      } else {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            message: "Admin can access only access this pages!"
          },
          HttpStatus.BAD_REQUEST
        );
      }
    } catch (error) {
       throw new BadRequestException(error.response);
    }
  }
}
