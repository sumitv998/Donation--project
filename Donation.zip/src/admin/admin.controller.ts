import {
  Post,
  Put,
  Get,
  Query,
  Req,
  UseGuards,
  Headers
} from "@nestjs/common";
import { Body } from "@nestjs/common";
import { Controller } from "@nestjs/common";
import { Projects } from "src/projects/entities/project.entity";
import { Species } from "src/species/entities/species.entity";
import { UsersCorporates } from "src/users/entities/usersCorporate.entity";
import { AdminService } from "./admin.service";
import { AdminPasswordSet } from "./dto/admin.forgetpassword.dto";
import { AdminLoginDto } from "./dto/admin.login.dto";
import { emailDto } from "./dto/mail.dto";
import { JwtAuthGuard } from "src/guards/jwt.guard";

@Controller("admin")
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  @Post("/login")
  login(
    @Body() loginDto: AdminLoginDto
    // @Res({ passthrough: true }) res: Response
  ) {
    return this.adminService.adminLogin(loginDto);
  }

  @Post("/forgotPassword")
  forgetPassword(@Body() email: emailDto) {
    return this.adminService.forgotAdminPassword(email);
  }

  // @UseGuards(JwtAuthGuard)
  @Put("/resetPassword")
  setPassword(
    @Headers("Authorization") token: string,
    @Body() adminPassword: AdminPasswordSet,
    @Req() req,
  ): Promise<UsersCorporates> {
    return this.adminService.setPassword(req, adminPassword, token);
  }

  @UseGuards(JwtAuthGuard)
  @Get("/getProducts")
  getProduct(
    @Query("pageNo") pageNo: number,
    @Query("limit") limit: number,
    @Query("sorting") sorting: string,
    @Query("field") field: string,
    @Req() req
  ) {
    return this.adminService.getAllProductDetails(
      pageNo,
      limit,
      sorting,
      field,
      req
    );
  }

  @UseGuards(JwtAuthGuard)
  @Put("active")
  getTaskbyId(
    @Body() body,
    @Req() req
  ): Promise<Projects | Species | any> {
    return this.adminService.isActivePorduct(body,  req);
  }
}
