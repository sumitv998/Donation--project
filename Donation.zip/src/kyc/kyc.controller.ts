import {
  Body,
  Controller,
  Get,
  Post,
  Query,
  Req,
  UploadedFile,
  UploadedFiles,
  UseGuards,
  UseInterceptors,
} from "@nestjs/common";
import {
  FileFieldsInterceptor,
  FileInterceptor,
} from "@nestjs/platform-express";
import { KYCAuthGuard } from "src/guards/kyc.guard";
import KYCRolesGuard from "src/guards/kycRole.guard";
import { KYCfileValidation } from "src/services/filesValidation";
import { ROLE } from "src/users/entities/usersCorporate.entity";
import { companyDetailsDto } from "./dto/compayDetails.dto";
import { KycService } from "./kyc.service";

@Controller("kyc")
export class KycController {
  constructor(private readonly kycService: KycService) {}

  @UseGuards(KYCAuthGuard, KYCRolesGuard(ROLE.CORPORATE))
  @Post("/forgeryCheckForCorporate")
  @UseInterceptors(
    FileFieldsInterceptor(
      [
        { name: "companyDoc", maxCount: 1 },
        { name: "personDoc", maxCount: 1 },
      ],
      KYCfileValidation
    )
  )
  forgeryCheckForCorporate(
    @UploadedFiles(
      // new ParseFilePipeBuilder()
      //   .addMaxSizeValidator({ maxSize: 5000000 })
      //   .build({ errorHttpStatusCode: HttpStatus.UNPROCESSABLE_ENTITY })
    )
    files: {
      companyDoc?: Express.Multer.File;
      personDoc?: Express.Multer.File;
    },
    @Req() req,
    @Body() body: companyDetailsDto
  ) {
    return this.kycService.forgeryCheckForCorporate(
      files.companyDoc,
      files.personDoc,
      req,
      body
    );
  }

  @Post("/webhookForForgeryCheck")
  webhookForForgeryCheck(@Query("whose") whose, @Body() body: any) {
    return this.kycService.webhookForForgeryCheck(whose, body);
  }

  @UseGuards(KYCAuthGuard)
  @Post("/livenessCheckForPerson")
  livenessCheckForPerson(
    @Query("locale") locale: string,
    @Req() req
  ): Promise<any> {
    return this.kycService.livenessCheckForPerson(locale, req);
  }

  @Post("/webhookForLivenessCheck")
  webhookForLivenessCheck(@Body() body: any, @Query("userId") userId) {
    return this.kycService.webhookForLivenessCheck(body, userId);
  }

  @UseGuards(KYCAuthGuard)
  @Post("/forgeryCheckForUser") // it is for individual user
  @UseInterceptors(FileInterceptor("file", KYCfileValidation))
  forgeryCheckForPerson(
    @UploadedFile(
      // new ParseFilePipeBuilder()
      //   .addMaxSizeValidator({ maxSize: 5000000 })
      //   .build({ errorHttpStatusCode: HttpStatus.UNPROCESSABLE_ENTITY })
    )
    file: Express.Multer.File
  ): Promise<any> {
    const whose = "Person";
    return this.kycService.forgeryCheckForPerson(file, whose);
  }

  @UseGuards(KYCAuthGuard)
  @Get("/isKYCCompleted")
  isKYCCompleted(@Req() req) {
    return this.kycService.isKYCCompleted(req);
  }

  // for testing this is used after that will be delete
  @UseGuards(KYCAuthGuard, KYCRolesGuard(ROLE.CORPORATE))
  @Post("/pepAndSanctionCheckForCorporate")
  pepAndSanctionCheckForCorporate(@Req() req) {
    const user = req.user.email;
    return this.kycService.pepAndSanctionCheckForCorporate(user);
  }
}
