import { IsEmail, IsEnum, IsNotEmpty, IsString } from "class-validator";
import { ROLE } from "../../users/entities/usersCorporate.entity";
export class AdminLoginDto {
  @IsEmail()
  email: string;

  @IsNotEmpty()
  @IsString()
  password: string;
}
