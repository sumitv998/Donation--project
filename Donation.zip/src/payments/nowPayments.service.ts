import { HttpService } from "@nestjs/axios";
const axios = require("axios");
import {
  BadGatewayException,
  BadRequestException,
  ForbiddenException,
  Injectable,
  UnauthorizedException,
} from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { catchError, firstValueFrom, map, Observable } from "rxjs";
import { Repository } from "typeorm";
import * as crypto from "crypto";
import {
  nowPaymentsInvoice5WFDto,
  nowPaymentsInvoiceDto,
  TYPE,
} from "./dto/nowPayments.dto";
import { paymentTransactions, STATUS } from "./entities/payments.entity";
import { TransactionService } from "./transaction.repo";
import { LatestCurrencyPrice } from "./entities/latestCurrencyPrice.entity";
import { UsersCorporates } from "src/users/entities/usersCorporate.entity";
import { paymentEmailReceipt } from "src/services/paymentEmailReceipt.service";
import { SendGridEmailService } from "src/services/sendgridEmail.service";

@Injectable()
export class NowPaymentService {
  constructor(
    @InjectRepository(paymentTransactions)
    private readonly transactionRepo: Repository<paymentTransactions>,
    @InjectRepository(LatestCurrencyPrice)
    private readonly currencyPriceRepo: Repository<LatestCurrencyPrice>,
    @InjectRepository(UsersCorporates)
    private readonly usersCorporateRepo: Repository<UsersCorporates>,
    private readonly transactionService: TransactionService,
    private readonly emailService: SendGridEmailService,
    private readonly payReceipt: paymentEmailReceipt,
    private readonly httpService: HttpService
  ) {}

  async createInvoiceForCrypto(
    req,
    res,
    body: nowPaymentsInvoiceDto
  ): Promise<any> {
    try {
      const userId = req.user.userId;
      const {
        price_amount,
        price_currency,
        payCurrency,
        _5wfAmount,
        orderDescription,
      } = body;
      if (_5wfAmount) {
        orderDescription.push({
          productType: "5WF",
          productId: null,
          amount: _5wfAmount,
        });
      }
      const totalAmount = price_amount + _5wfAmount;
      const description = JSON.stringify(orderDescription);
      const response = await firstValueFrom(
        this.httpService
          .post(
            "https://api-sandbox.nowpayments.io/v1/invoice",
            {
              price_amount: totalAmount,
              price_currency: price_currency,
              pay_currency: payCurrency,
              order_id: userId,
              order_description: "Donation to 5WF Platform",
              ipn_callback_url: `${process.env.IPN_CALLBACK_URL}`,
              success_url: `${process.env.SUCCESS_URL}?pay_amount=${totalAmount}`,
              cancel_url: `${process.env.FAILURE_URL}?pay_amount=${totalAmount}`,
            },
            {
              headers: {
                "x-api-key": process.env.NOWPAY_API_KEY,
                "Content-Type": "application/json",
              },
            }
          )
          .pipe(
            map(async (res) => {
              return res.data;
            })
          )
          .pipe(
            catchError((e) => {
              console.log(e);
              throw new ForbiddenException("API not available");
            })
          )
      );
      // storing products' data in database
      await this.transactionService.createTransactionForCrypto(
        body,
        response.id,
        description,
        userId,
        totalAmount
      );
      res.json({ invoice_url: response.invoice_url });
    } catch (error) {
      throw new BadGatewayException(error.message);
    }
  }

  async createInvoiceFor5WF(req, res, body: nowPaymentsInvoice5WFDto) {
    try {
      const userId = req.user.userId;
      const { price_amount, price_currency, payCurrency } = body;
      const response = await firstValueFrom(
        this.httpService
          .post(
            "https://api-sandbox.nowpayments.io/v1/invoice",
            {
              price_amount: price_amount,
              price_currency: price_currency,
              pay_currency: payCurrency,
              order_id: userId,
              order_description: "Donation for 5WF",
              ipn_callback_url: `${process.env.IPN_CALLBACK_URL}`,
              success_url: `${process.env.SUCCESS_URL}?pay_amount=${price_amount}`,
              cancel_url: `${process.env.FAILURE_URL}?pay_amount=${price_amount}`,
            },
            {
              headers: {
                "x-api-key": process.env.NOWPAY_API_KEY,
                "Content-Type": "application/json",
              },
            }
          )
          .pipe(
            map(async (res) => {
              return res.data;
            })
          )
          .pipe(
            catchError((e) => {
              console.log(e);
              throw new ForbiddenException("API not available");
            })
          )
      );
      await this.transactionService.createTransactionForCrypto5WF(
        body,
        response,
        userId
      );
      res.json({ invoice_url: response.invoice_url });
    } catch (error) {
      throw new BadGatewayException(error.message);
    }
  }

  async callbackNotificationForCrypto(req, body: any) {
    try {
      console.log(body);
      const hmac = crypto
        .createHmac("sha512", process.env.IPN_SECRET_KEY)
        .update(JSON.stringify(body, Object.keys(body).sort()))
        .digest("hex");
      let status: string;
      let message: string;
      if (hmac === req.headers["x-nowpayments-sig"]) {
        if (body.payment_status == "finished") {
          status = STATUS.SUCCESS;
          message = "payment successful";
          console.log(body.payment_status);
        } else if (body.payment_status == "refunded") {
          status = STATUS.REFUNDED;
          message = "the funds were refunded back to the user";
          console.log(body.payment_status);
        } else if (body.payment_status == "failed") {
          status = STATUS.FAILED;
          message = "payment failed";
          console.log(body.payment_status);
        } else if (body.payment_status == "expired") {
          status = STATUS.EXPIRED;
          message = "payment session expired";
          console.log(body.payment_status);
        } else {
          throw new BadRequestException("Something went wrong with payment");
        }
        const invoiceId = body.invoice_id;
        const paidCurrency = body.pay_currency;
        const totalAmount = body.pay_amount;
        const userId = body.order_id;
        let statusImg = "";
        await this.transactionRepo.query(
          `update payment_transactions SET status='${status}', 
        "paidAmount"= "paidAmount" * ${body.pay_amount} WHERE "invoiceId" ='${invoiceId}'`
        );
        if (status == "Success") {
          statusImg += `<div class="justifyCenterClass">
          <img src="https://fivewfstaging.s3.ap-south-1.amazonaws.com/success.png" alt="Success" class="statusImg" />
        </div>`;
        }
        if (status == "Failed") {
          statusImg += `<div class="justifyCenterClass">
          <img src="https://fivewfstaging.s3.ap-south-1.amazonaws.com/fail.png" alt="Failed" class="statusImg" />
        </div>`;
        }
        this.sendPaymentReceipt(invoiceId, userId, statusImg, paidCurrency, totalAmount);
        return message;
      } else {
        throw new UnauthorizedException("payment is not authorised");
      }
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async sendPaymentReceipt(
    invoiceId: string,
    userId: string,
    statusImg:string,
    paidCurrency: string,
    totalAmount: number
  ) {
    const customerEmail = await this.usersCorporateRepo.query(
      `select uc.email from users_corporates uc where uc.id = '${userId}'`
    );
    const items = await this.transactionRepo
      .query(`select pt."invoiceId", pt."is5WF", s.id as "speciesId", p.id as "projectId",
    s."speciesName", p."projectName", pt."paidCurrency", pt."paidAmount"
    from payment_transactions pt left join species s on s.id = pt."speciesId" 
    left join projects p on p.id = pt."projectId" 
    where "invoiceId" = '${invoiceId}'`);
    let itemHtml = "";
    const subject = "5W Foundation Donation Payment Receipt";
    for (let i in items) {
      let item = "";
      if (items[i].is5WF == true) {
        item += "5W Foundation";
      }
      if (items[i].speciesId != null) {
        item += `${items[i].speciesName}`;
      }
      if (items[i].projectId != null) {
        item += `${items[i].projectName}`;
      }

      itemHtml += `<tr>
      <td data-label="Product Name">${item}</td>
      <td align="right" data-label="Amount">${items[
        i
      ].paidCurrency.toUpperCase()} ${items[i].paidAmount}</td>
    </tr>`;
    }
    const emailInfo = await this.payReceipt.paymentReceipt(
      invoiceId,
      itemHtml,
      statusImg,
      paidCurrency,
      totalAmount
    );
    await this.emailService.sendEmail(customerEmail, subject, emailInfo);
  }

  async getLatestAmountForUSD() {
    const base = "usd";
    const symbols = [
      "usd",
      "eur",
      "cad",
      "gbp",
      "aud",
      "hkd",
      "inr",
      "jpy",
      "sgd",
      "zar",
      "chf",
      "aed",
      "btc",
      "eth",
      "xrp",
      "doge",
      "sol",
      "ada",
      "hbar",
      "ltc",
      "dash",
      "bch",
      "zec",
      "xlm", //XRP, DOGE, SOL, ADA, HBAR, LTC, DASH, BCH, ZEC, XLM
    ];
    const response = await firstValueFrom(
      this.httpService
        .get(
          `https://min-api.cryptocompare.com/data/price?fsym=${base}&tsyms=${symbols}`
        )
        .pipe(
          map(async (res) => {
            return res.data;
          })
        )
        .pipe(
          catchError((e) => {
            console.log(e);
            throw new ForbiddenException("API not available");
          })
        )
    );
    console.log("object", response);
    const exist = await this.currencyPriceRepo.query(
      `select id from latest_currency_price`
    );
    console.log("::::::::::::", exist.length == 0);
    if (exist.length == 0) {
      await this.currencyPriceRepo.save(response);
    } else {
      await this.currencyPriceRepo.update({ id: exist[0].id }, response);
    }
    return response;
  }
}
