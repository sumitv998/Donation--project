import { HttpModule } from "@nestjs/axios";
import { Module } from "@nestjs/common";
import { ScheduleModule } from "@nestjs/schedule";
import { TypeOrmModule } from "@nestjs/typeorm";
import { Projects } from "src/projects/entities/project.entity";
import { paymentEmailReceipt } from "src/services/paymentEmailReceipt.service";
import { SendGridEmailService } from "src/services/sendgridEmail.service";
import { Species } from "src/species/entities/species.entity";
import { UsersCorporates } from "src/users/entities/usersCorporate.entity";
import { LatestCurrencyPrice } from "./entities/latestCurrencyPrice.entity";
import { paymentTransactions } from "./entities/payments.entity";
import { NowPaymentService } from "./nowPayments.service";
import { PaymentsController } from "./payments.controller";
import { StripeService } from "./stripe.service";
import { TransactionService } from "./transaction.repo";

@Module({
  imports: [
    TypeOrmModule.forFeature([
      paymentTransactions,
      UsersCorporates,
      Species,
      Projects,
      LatestCurrencyPrice,
    ]),
    ScheduleModule.forRoot(),
    HttpModule.register({ timeout: 5000, maxRedirects: 5 }),
  ],
  controllers: [PaymentsController],
  providers: [
    NowPaymentService,
    StripeService,
    TransactionService,
    paymentEmailReceipt,
    SendGridEmailService,
  ],
  exports: [PaymentsModule],
})
export class PaymentsModule {}
