import { ApiProperty } from "@nestjs/swagger";
import { favouriteProject } from "src/favourite/entities/favProjects.entity";
import { paymentTransactions } from "src/payments/entities/payments.entity";
import { GEOGRAPHICREGION, Species } from "src/species/entities/species.entity";
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToMany,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import { AssetProjects } from "./assetsProject.entity";

@Entity()
export class Projects {
  @PrimaryGeneratedColumn("uuid")
  public id: string;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  projectName: string;

  // @ApiProperty()
  // @ManyToMany(() => UsersCorporates, (users: UsersCorporates) => users.projects)
  // public users: UsersCorporates;

  @OneToMany(
    () => favouriteProject,
    (favProject: favouriteProject) => favProject.user
  )
  favProject: favouriteProject[];

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  geographicRegion: GEOGRAPHICREGION;

  @ManyToOne(() => Species, (species: Species) => species.project)
  @JoinColumn({ name: "speciesId" })
  species: Species;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  conservationActivity: CONSERVATIONACTIVITY;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  overview: string;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  projectDetails: string;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  projectBenifit: string;

  @Column({ type: "boolean", default: false })
  isActive: boolean;

  @Column({ type: "boolean", default: false })
  isOcean: boolean;

  @ApiProperty()
  @Column({ default: 0, type: "int8", nullable: true })
  likesCount: number;

  @ApiProperty()
  @OneToMany(() => AssetProjects, (assets: AssetProjects) => assets.projects)
  assets: AssetProjects[];

  @ApiProperty()
  @OneToMany(
    () => paymentTransactions,
    (projectTransaction: paymentTransactions) => projectTransaction.project
  )
  projectTransaction: paymentTransactions[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}

export enum CONSERVATIONACTIVITY {
  ALL = "All",
  Site_Area_Protection = "Site/Area Protection",
  Resource_Habitate_Protection = "Resource/Habitat Protection",
  Ecosystem_Natural_Process_Restoration = "Ecosystem/Natural Process Restoration",
  Species_Management = "Species Management",
  Species_Re_Introduction = "Species Re-Introduction",
  Ex_Situ_Conservation = "Ex-Situ Conservation",
  Outreach_Education = "Outreach Education",
  Raising_Awareness = "Raising Awareness",
  Anti_Wildlife_Poaching_Trafficking = "Anti-Wildlife Poaching Trafficking",
  Conservation_Planning = "Conservation Planning",
  Research_Status_Monitoring = "Research and Status Monitoring",
}
