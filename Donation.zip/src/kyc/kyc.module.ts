import { HttpModule } from "@nestjs/axios";
import { Module } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { TypeOrmModule } from "@nestjs/typeorm";
import { KYCStrategy } from "src/guards/kyc.strategy";
import { S3Service } from "src/services/s3.service";
import { SendGridEmailService } from "src/services/sendgridEmail.service";
import { UsersCorporates } from "src/users/entities/usersCorporate.entity";
import { kycDetails } from "./entities/companyInfo.entity";
import { KycController } from "./kyc.controller";
import { KycService } from "./kyc.service";

@Module({
  imports: [
    TypeOrmModule.forFeature([kycDetails, UsersCorporates]),
    HttpModule.register({ timeout: 5000, maxRedirects: 5 }),
  ],
  controllers: [KycController],
  providers: [
    KycService,
    S3Service,
    JwtService,
    KYCStrategy,
    SendGridEmailService,
  ],
})
export class KycModule {}
