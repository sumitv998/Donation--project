import {
  BadRequestException,
  HttpException,
  HttpStatus,
  Injectable,
  NotFoundException,
  UnauthorizedException,
} from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository } from "typeorm";
import * as bcrypt from "bcrypt";
import { Response, Request } from "express";
import { CreateCorporateDto } from "./dto/createCorporate.dto";
import { CreateUserDto } from "./dto/createUser.dto";
import { ROLE, UsersCorporates } from "./entities/usersCorporate.entity";
import { LoginDto } from "./dto/userLogin.dto";
import { JwtService } from "@nestjs/jwt";
import { ForgortPaaswordDto } from "./dto/forgotPassword.dto";
import { SetPasswordDto } from "./dto/setPassword.dto";
import { favouriteSpecies } from "src/favourite/entities/favSpecies.entity";
import {
  CATEGORY,
  GEOGRAPHICREGION,
  HABITATETYPE,
  Species,
} from "src/species/entities/species.entity";
import {
  CONSERVATIONACTIVITY,
  Projects,
} from "src/projects/entities/project.entity";
import { favouriteProject } from "src/favourite/entities/favProjects.entity";
import { SendGridEmailService } from "src/services/sendgridEmail.service";
import { EditProfileDto } from "./dto/editProfile.dto";
import { S3Service } from "src/services/s3.service";
import { responseValidation } from "src/services/responseHandler";
import { SPECIESNAME } from "./dto/speciesDashboard.dto";
import { PROJECTNAME } from "./dto/projectDashboard.dto";
import { paymentTransactions } from "src/payments/entities/payments.entity";
import { createDonation } from "src/favourite/dto/createDonation.dto";
import { mailFormat } from "./../config/mailFormat";
import { Countries } from "src/config/countries";
import { kycDetails } from "src/kyc/entities/companyInfo.entity";

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(UsersCorporates)
    private usersCorporateRepository: Repository<UsersCorporates>,
    @InjectRepository(favouriteSpecies)
    private favouriteSpecies: Repository<favouriteSpecies>,
    @InjectRepository(favouriteProject)
    private favouriteProjects: Repository<favouriteProject>,
    @InjectRepository(Species)
    private readonly speciesRepository: Repository<Species>,
    private readonly s3Service: S3Service,
    private readonly getCountryAPI: Countries,
    private readonly validResponse: responseValidation,
    @InjectRepository(Projects)
    private readonly projectRepository: Repository<Projects>,
    @InjectRepository(paymentTransactions)
    private readonly paymentRepo: Repository<paymentTransactions>,
    @InjectRepository(kycDetails)
    private readonly kycDetailsRepo: Repository<kycDetails>,
    private readonly sendgridEmailService: SendGridEmailService,
    private readonly mailFormat: mailFormat,
    private jwtService: JwtService
  ) {}

  async verifyEmail(req: Request): Promise<any> {
    const userRole = req.body.userRole;
    const email = req.body.email;
    const user = await this.getUserOrCorporate({ email });
    if (user) {
      throw new BadRequestException("user is already exist, please login");
    }
    // generate token
    const token = await this.jwtService.signAsync(
      { userRole: userRole, email: email },
      { secret: process.env.JWT_SECRET, expiresIn: "1d" }
    );
    const subject =
      "5W Foundation - Email Verification Request and Create Password";
    const name = userRole;
    const link = `${process.env.TOKEN_URL}${token}`;
    const what = "and create password to complete the registration process";
    let newEmailMsg = this.mailFormat.mailHtmlFormat(name, what, link);

    // Sending email with JW Token
    console.log(email, token);
    await this.sendgridEmailService.sendEmail(email, subject, newEmailMsg);
    return { success: 200, message: "email sent successfully" };
  }

  async createPassword(token: string, body: SetPasswordDto): Promise<any> {
    try {
      if (!token) {
        throw new BadRequestException("jwt token required");
      }
      const jwt = token.split(" ");
      const decodeHeader = await this.jwtService.verifyAsync(jwt[1], {
        secret: process.env.JWT_SECRET,
      });
      const { userRole, email } = decodeHeader;
      const isExist = await this.usersCorporateRepository.findOneBy({
        email: email,
      });
      if (isExist) {
        if (isExist.userRole == ROLE.ADMIN) {
          throw new BadRequestException("Admin can not access");
        }
        if (isExist.passToken != jwt[1] || null) {
          throw new BadRequestException(
            "token has been expired or invalid token, please resend link"
          );
        }
        const matchPass = await bcrypt.compare(body.password, isExist.password);
        if (matchPass) {
          throw new BadRequestException(
            "password shouldn't match with previous password"
          );
        }
        const salt = await bcrypt.genSalt();
        const hashPassword = await bcrypt.hash(body.password, salt);
        await this.usersCorporateRepository.update(
          { email: email },
          { password: hashPassword, passToken: null }
        );
        return { success: true, message: "Password reset successfully" };
      } else {
        const salt = await bcrypt.genSalt();
        const hashedPassword = await bcrypt.hash(body.password, salt);
        const Obj = new UsersCorporates();
        Obj.userRole = userRole;
        Obj.email = email;
        Obj.password = hashedPassword;
        await this.usersCorporateRepository.save(Obj);
        const jwt = await this.jwtService.signAsync(
          { userRole: userRole, email: email },
          { secret: process.env.JWT_SECRET, expiresIn: "1d" }
        );
        return {
          success: 200,
          token: jwt,
          message:
            "password created successfully, now you can complete your profile",
        };
      }
    } catch (error) {
      if (error.message == "invalid token") {
        throw new BadRequestException("oops!, you are unauthorized");
      } else if (error.message == "jwt expired") {
        throw new BadRequestException("oops!, your session is expired");
      } else {
        throw new BadRequestException({
          message: error.message,
          code: error.code,
        });
      }
    }
  }

  async userProfile(token: string, body: CreateUserDto): Promise<any> {
    try {
      if (!token) {
        throw new BadRequestException("jwt token required");
      }
      const jwt = token.split(" ");
      const decodeHeader = await this.jwtService.verifyAsync(jwt[1], {
        secret: process.env.JWT_SECRET,
      });
      const { userRole, email } = decodeHeader;
      const { favSpecies } = body;
      if (userRole !== ROLE.USER) {
        throw new UnauthorizedException("you are not individual user");
      }
      const found = await this.getUserOrCorporate({ email });
      if (!found) {
        throw new BadRequestException("unable to proceed, you need to signup");
      }
      const objUpdated = await this.usersCorporateRepository.update(
        { email: email },
        body
      );
      if (!objUpdated) {
        throw new BadRequestException("unable to update details");
      }
      for (let favSpecie of favSpecies) {
        await this.favouriteSpecies.save({
          user: found,
          species: favSpecie,
          isFavourite: true,
        });
      }
      const response = await this.usersCorporateRepository
        .createQueryBuilder("p")
        .where({ userRole: userRole })
        .select([
          "p.firstName",
          "p.lastName",
          "p.age",
          "p.gender",
          "p.city",
          "p.country",
        ])
        .getOne();
      return this.validResponse.validateResponse(
        response,
        null,
        "successfully signup"
      );
    } catch (error) {
      if (error.message == "invalid token") {
        throw new BadRequestException(
          "oops!, you are unauthorized or invalid token"
        );
      } else if (error.message == "jwt expired") {
        throw new BadRequestException("oops!, your session is expired");
      } else {
        throw new BadRequestException({
          message: error.message,
          code: error.code,
        });
      }
    }
  }

  async corporateProfile(
    token: string,
    body: CreateCorporateDto
  ): Promise<any> {
    try {
      if (!token) {
        throw new BadRequestException("jwt token required");
      }
      const jwt = token.split(" ");
      const decodeHeader = await this.jwtService.verifyAsync(jwt[1], {
        secret: process.env.JWT_SECRET,
      });
      const { userRole, email } = decodeHeader;
      if (userRole !== ROLE.CORPORATE) {
        throw new UnauthorizedException("you are not corporate user");
      }
      const found = await this.getUserOrCorporate({ email });
      if (!found) {
        throw new BadRequestException("unable to proceed, you need to signup");
      }
      const { companyName, favSpecies } = body;
      const existCompany = await this.getUserOrCorporate({ companyName });
      if (existCompany) {
        throw new BadRequestException("company is already exist");
      }
      const objUpdated = await this.usersCorporateRepository.update(
        { email: email },
        {
          companyName: body.companyName,
          sector: body.sector,
          representativeName: body.representativeName,
          position: body.position,
          representativeEmail: body.representativeEmail,
          city: body.city,
          country: body.country,
        }
      );
      if (!objUpdated) {
        throw new BadRequestException("unable to proceed");
      }
      for (let favSpecie of favSpecies) {
        await this.favouriteSpecies.save({
          user: found,
          species: favSpecie,
          isFavourite: true,
        });
      }
      const response = await this.usersCorporateRepository
        .createQueryBuilder("c")
        .where({ email: email })
        .select([
          "c.companyName",
          "c.sector",
          "c.city",
          "c.country",
          "c.representativeName",
          "c.position",
        ])
        .getOne();
      return this.validResponse.validateResponse(
        response,
        null,
        "completed your profile successfully, now proceed for KYC process"
      );
    } catch (error) {
      if (error.message == "invalid token") {
        throw new BadRequestException(
          "oops!, you are unauthorized or invalid token"
        );
      } else if (error.message == "jwt expired") {
        throw new BadRequestException("oops!, your session is expired");
      } else {
        throw new BadRequestException({
          message: error.message,
          code: error.code,
        });
      }
    }
  }

  async login(body: LoginDto, res: Response): Promise<any> {
    const { email, password } = body;
    let user = await this.getUserOrCorporate({ email });
    if (!user) {
      throw new NotFoundException("email is not registered, please signup");
    }
    if (user.password == null) {
      throw new NotFoundException(
        "Password is not set, please set password first"
      );
    }
    const pswd = await bcrypt.compare(password, user.password);
    if (!pswd) {
      throw new BadRequestException("Password incorrect");
    }
    if (user.isVerified == false) {
      const jwt = await this.jwtService.signAsync(
        { userRole: user.userRole, email: user.email },
        { secret: process.env.JWT_SECRET, expiresIn: "1d" }
      );
      if (user.city == null) {
        return {
          completeProfile: false,
          KYC: false,
          success: 200,
          token: jwt,
          message: "now you have to complete your profile",
        };
      } else {
        const data = await this.kycDetailsRepo
          .query(`select kd."isLivenessCheckVerified", kd."pepSanctionForCompany", kd."pepSanctionForPerson",
              kd."forgeryForPerson", kd."forgeryForCompany" from kyc_details kd where "userId" = '${user.id}'`);
        if (data[0]) {
          const {
            isLivenessCheckVerified,
            forgeryForCompany,
            forgeryForPerson,
            pepSanctionForCompany,
            pepSanctionForPerson,
          } = data[0];
          console.log("forgeryForCompany:::::::", forgeryForCompany);
          console.log("forgeryForPerson:::::::", forgeryForPerson);
          if (forgeryForCompany == true && forgeryForPerson == true) {
            if (isLivenessCheckVerified != "Success") {
              return {
                completeProfile: true,
                forgeryCheck: true,
                liveness: false,
                success: 200,
                token: jwt,
                message: "please proceed for liveness test",
              };
            }
            if (
              (isLivenessCheckVerified == "Success" &&
                pepSanctionForCompany != null) ||
              pepSanctionForPerson != null
            ) {
              throw new BadRequestException(
                "You or Your Company involved in PEP/SANCTION, please wait for approval"
              );
            } else {
              throw new BadRequestException(
                "Something went wrong with KYC, please contact to 5WF Organization"
              );
            }
          } else {
            return {
              completeProfile: true,
              forgeryCheck: false,
              liveness: false,
              success: 200,
              token: jwt,
              message: "proceed for KYC verification",
            };
          }
        } else {
          return {
            completeProfile: true,
            KYC: false,
            success: 200,
            token: jwt,
            message: "proceed for KYC verification",
          };
        }
      }
    } else if (user.email === email && pswd && user.isVerified == true) {
      const token = await this.jwtService.signAsync(
        {
          userId: user.id,
          userRole: user.userRole,
          email: user.email,
        },
        {
          secret: process.env.LOGIN_SECRET,
          expiresIn: "7d",
        }
      );
      return {
        success: 200,
        KYC: true,
        completeProfile: true,
        userImage: user.profileImage,
        token: token,
        userEmail: user.email,
        message: "login successfully",
      };
    } else {
      throw new NotFoundException("Credentials are invalid");
    }
  }

  async dashboardForSpecies(
    token: string,
    speciesName: SPECIESNAME,
    IUCNRedList: CATEGORY,
    habitateType: HABITATETYPE,
    geographicRegion: GEOGRAPHICREGION,
    key: string,
    page: number,
    limit: number
  ) {
    try {
      let where = "";
      let who = "";
      let like = "";
      let liked = "";
      if (key !== "All") {
        where += `and s."speciesName" ~* '${key}[A-Z]*'`;
      }
      if (speciesName != SPECIESNAME.ALL) {
        where += `and s."speciesName" ~* '^[${speciesName}]'`;
      }
      if (IUCNRedList != CATEGORY.ALL) {
        where += `and s."category" = '${IUCNRedList}'`;
      }
      if (habitateType != HABITATETYPE.ALL) {
        where += `and s."habitateType" = '${habitateType}'`;
      }
      if (geographicRegion != GEOGRAPHICREGION.ALL) {
        where += `and s."geographicRegion" = '${geographicRegion}'`;
      }
      if (token) {
        const jwt = token.split(" ");
        const decodeHeader = await this.jwtService.verifyAsync(jwt[1], {
          secret: process.env.LOGIN_SECRET,
        });
        who += `and '${decodeHeader.userId}' = fs2."userId" `;
        like += `, fs2."isLiked", fs2."isFavourite", fs2.carts`;
        liked += `fs2."isLiked" = false asc, fs2."isFavourite" = false asc,`;
      }
      const speciesDashboard = await this.speciesRepository
        .query(`select * from (select s.id, s."speciesName",s."speciesNameScientific",
      s.category,s.overview,s."speciesDetails" ${like},as2.url as "imageURL",
      (select count(nullif(fs3."isLiked",false))
      from favourite_species fs3 where s.id = fs3."speciesId" )as likes,
      row_number() over (partition by s.id) as rowNumber from species s 
      left join favourite_species fs2 on s.id = fs2."speciesId" ${who}
      left join asset_species as2 on s.id = as2."speciesId" 
      and as2."type" = 'coverImage' where s."isActive" = true ${where}
      order by ${liked} s."speciesName" asc) as tempTable where tempTable.rowNumber = 1 `);

      let data = [...speciesDashboard];
      let result = [];
      if (!page) page = 1;
      if (!limit) {
        data.length < 12 ? (limit = data.length) : (limit = 12);
      }
      let pageSize = Math.ceil(data.length / limit);
      for (
        let i = (page - 1) * limit;
        i < page * limit && i < data.length;
        i++
      ) {
        result.push(data[i]);
      }
      if (result.length <= 0) {
        return {
          totalCount: data.length,
          data: data,
        };
      } else {
        return {
          totalCount: data.length,
          pageCount: pageSize,
          rowCount: result.length,
          data: result,
        };
      }
    } catch (error) {
      if (error.message == "invalid token") {
        throw new BadRequestException(
          "oops!, you are unauthorized or invalid token"
        );
      } else if (error.message == "jwt expired") {
        throw new BadRequestException("oops!, your session is expired");
      } else if (error.message == "invalid signature") {
        throw new BadRequestException(
          "oops!, your signup process is still pending or need to be logged in first"
        );
      } else {
        throw new BadRequestException({
          message: error.message,
          code: error.code,
        });
      }
    }
  }

  async dashboardForProjects(
    token: string,
    projectName: PROJECTNAME,
    geographicRegion: GEOGRAPHICREGION,
    conservationActivity: CONSERVATIONACTIVITY,
    key: string,
    page: number,
    limit: number
  ): Promise<any> {
    try {
      let where = "";
      let who = "";
      let like = "";
      let liked = "";
      if (key !== "All") {
        where += `and p."projectName" ~* '${key}[A-Z]*'`;
      }
      if (projectName != PROJECTNAME.ALL) {
        where += `and p."projectName" ~* '^[${projectName}]'`;
      }
      if (geographicRegion != GEOGRAPHICREGION.ALL) {
        where += `and p."geographicRegion" = '${geographicRegion}'`;
      }
      if (conservationActivity != CONSERVATIONACTIVITY.ALL) {
        where += `and p."conservationActivity" = '${conservationActivity}'`;
      }
      if (token) {
        const jwt = token.split(" ");
        const decodeHeader = await this.jwtService.verifyAsync(jwt[1], {
          secret: process.env.LOGIN_SECRET,
        });
        var userId = decodeHeader.userId;
        who += `and '${userId}' = fp."userId"`;
        like += `, fp."isLiked", fp."isFavourite", fp.carts`;
        liked += `fp."isLiked" = false asc, fp."isFavourite" = false asc,`;
      }
      const projectDashboard = await this.projectRepository
        .query(`select * from (select p.id , p."projectName" , p.overview, p."geographicRegion" ,p."projectDetails" ${like}, 
        ap.url as "imageURL" ,
    (select count(nullif(fp2."isLiked", false)) from favourite_project fp2 where p.id = fp2."projectId") as likes,
    row_number() over (partition by p.id) as rowNumber from projects p 
    left join favourite_project fp on p.id = fp."projectId" ${who}
    left join asset_projects ap on p.id = ap."projectId" and ap."type" = 'coverImage'
    where p."isActive" = true ${where}
    order by ${liked} p."projectName" asc) as tempTable where tempTable.rowNumber = 1`);

      let data = [...projectDashboard];
      let result = [];
      if (!page) page = 1;
      if (!limit) {
        data.length < 12 ? (limit = data.length) : (limit = 12);
      }
      let pageSize = Math.ceil(data.length / limit);
      for (
        let i = (page - 1) * limit;
        i < page * limit && i < data.length;
        i++
      ) {
        result.push(data[i]);
      }
      if (result.length <= 0) {
        return {
          totalCount: data.length,
          data: data,
        };
      } else {
        return {
          totalCount: data.length,
          pageCount: pageSize,
          rowCount: result.length,
          data: result,
        };
      }
    } catch (error) {
      if (error.message == "invalid token") {
        throw new BadRequestException(
          "oops!, you are unauthorized or invalid token"
        );
      } else if (error.message == "jwt expired") {
        throw new BadRequestException("oops!, your session is expired");
      } else if (error.message == "invalid signature") {
        throw new BadRequestException(
          "oops!, your signup process is still pending or need to be logged in first"
        );
      } else {
        throw new BadRequestException({
          message: error.message,
          code: error.code,
        });
      }
    }
  }

  async speciesDetails(token, speciesId: string, req) {
    try {
      let whose = "";
      let favCarts = "";
      let tempCarts = "";
      if (token) {
        const jwt = token.split(" ");
        const decodeHeader = await this.jwtService.verifyAsync(jwt[1], {
          secret: process.env.LOGIN_SECRET,
        });
        if (decodeHeader.userRole == "Admin") {
          throw new BadRequestException("Admin can not access");
        }
        var userId = decodeHeader.userId;
        whose += `left join favourite_species fav on s.id = fav."speciesId"  and fav."userId" = '${userId}'`;
        favCarts += `, fav."carts", fav."userId"`;
        tempCarts += `, tmp.carts`;
      }
      const response = await this.speciesRepository
        .query(`with tmp as (select s.id, s."speciesName", s."speciesNameScientific", s."geographicRegion", s."category", 
          s.overview, s."speciesDetails", as2."speciesId", as2."type" ${favCarts} ,
          jsonb_agg(as2.url) as urlPath from species s
          left join asset_species as2 
          on s.id = as2."speciesId" 
          ${whose}
          group by as2."type", as2."speciesId", s.id, s."speciesName", s."speciesNameScientific", s."geographicRegion", s."category", 
          s.overview, s."speciesDetails" ${favCarts} )
          select tmp.id, tmp."speciesName",tmp."speciesNameScientific", tmp."geographicRegion", tmp."category", 
          tmp.overview, tmp."speciesDetails", jsonb_object_agg(coalesce("type", 'NA') , coalesce(urlPath, null)) as ImagePath ${tempCarts}
          from species s2 left join tmp on s2.id = tmp.id where s2.id = '${speciesId}' 
          group by tmp.id, tmp."speciesName", tmp."speciesNameScientific",tmp."geographicRegion", tmp."category", 
          tmp.overview, tmp."speciesDetails" ${tempCarts}`);
      return this.validResponse.validateResponse(response, null, "Successful");
    } catch (error) {
      if (error.message == "invalid token") {
        throw new BadRequestException(
          "oops!, you are unauthorized or invalid token"
        );
      } else if (error.message == "jwt expired") {
        throw new BadRequestException("oops!, your session is expired");
      } else if (error.message == "invalid signature") {
        throw new BadRequestException(
          "oops!, your signup process is still pending or need to be logged in first"
        );
      } else {
        throw new BadRequestException({
          message: error.message,
          code: error.code,
        });
      }
    }
  }

  async projectDetails(token, projectId: string, req) {
    try {
      let whose = "";
      let favCarts = "";
      let tempCarts = "";
      if (token) {
        const jwt = token.split(" ");
        const decodeHeader = await this.jwtService.verifyAsync(jwt[1], {
          secret: process.env.LOGIN_SECRET,
        });
        if (decodeHeader.userRole == "Admin") {
          throw new BadRequestException("Admin can not access");
        }
        var userId = decodeHeader.userId;
        whose += `left join favourite_project fp on p.id = fp."projectId" and fp."userId" = '${userId}'`;
        favCarts += `, fp.carts, fp."userId"`;
        tempCarts += `, tmp.carts`;
      }
      const response = await this.projectRepository
        .query(`with tmp as (select p.id, p."projectName", p."geographicRegion", p."conservationActivity", 
          p.overview, p."projectDetails", p."projectBenifit", ap."projectId", ap."type" ${favCarts},
          jsonb_agg(ap.url) as urlPath from projects p  
          left join asset_projects ap 
          on p.id = ap."projectId" 
          ${whose}
          group by ap."type", ap."projectId", p.id, p."projectName", p."geographicRegion", p."conservationActivity", 
          p.overview, p."projectDetails", p."projectBenifit" ${favCarts})
          select tmp.id, tmp."projectName",tmp."geographicRegion", tmp."conservationActivity", 
          tmp.overview, tmp."projectDetails", tmp."projectBenifit", jsonb_object_agg(coalesce("type", 'NA') , coalesce(urlPath, null)) as ImagePath ${tempCarts} 
          from projects p2 left join tmp on p2.id = tmp.id where p2.id = '${projectId}'
          group by tmp.id, tmp."projectName", tmp."geographicRegion", tmp."conservationActivity", 
          tmp.overview, tmp."projectDetails", tmp."projectBenifit" ${tempCarts}`);
      return this.validResponse.validateResponse(response, null, "Successful");
    } catch (error) {
      if (error.message == "invalid token") {
        throw new BadRequestException(
          "oops!, you are unauthorized or invalid token"
        );
      } else if (error.message == "jwt expired") {
        throw new BadRequestException("oops!, your session is expired");
      } else if (error.message == "invalid signature") {
        throw new BadRequestException(
          "oops!, your signup process is still pending or need to be logged in first"
        );
      } else {
        throw new BadRequestException({
          message: error.message,
          code: error.code,
        });
      }
    }
  }

  async speciesForFavorite(): Promise<any> {
    const response = await this.speciesRepository.query(
      `select * from (
        select 
        s.id
        , s."speciesName"
        , as2."url" as imagePath
        , row_number() over (partition by as2."speciesId") as rowNumber
        from species s 
        left join asset_species as2 
        on s.id = as2."speciesId" 
        where as2."type" = 'coverImage'
        ) as tempTable where tempTable.rowNumber = 1 `
    );
    return this.validResponse.validateResponse(response, null, "Successful");
  }

  async forgotPassword(body: ForgortPaaswordDto) {
    try {
      const user = await this.usersCorporateRepository.findOneBy({
        email: body.email,
      });
      if (!user) {
        throw new BadRequestException("User does not exist");
      }
      const { email, userRole } = user;
      if (userRole == "Admin") {
        throw new BadRequestException("Admin cannot login to user dashboard");
      }
      const token = await this.jwtService.signAsync(
        { userRole: userRole, email: email },
        { secret: process.env.JWT_SECRET, expiresIn: "1d" }
      );
      let name = "";
      if (userRole == "User") {
        if (user.city == null) {
          name += "User";
        } else {
          name += `${user.firstName + user.lastName}`;
        }
      }
      if (userRole == "Corporate") {
        if (user.city == null) {
          name += "User";
        } else {
          name += `${user.representativeName}`;
        }
      }
      const what = " and reset password";
      const link = `${process.env.PASS_TOKEN_URL}${token}`;
      // for local testing
      let newEmailMsg = this.mailFormat.mailHtmlFormat(name, what, link);
      const subject =
        "5W Foundation - Email Verification Request and Reset Password";

      // Sending email with JW Token
      console.log(user.email, token);
      const response = await this.sendgridEmailService.sendEmail(
        email,
        subject,
        newEmailMsg
      );
      await this.usersCorporateRepository.update(
        { email: email },
        { passToken: token }
      );
      return this.validResponse.validateResponse(
        response,
        null,
        "email sent successfully"
      );
    } catch (error) {
      console.error("Error :::: userService :::: forgot Password ", error);
      throw new BadRequestException({ message: error.message });
    }
  }

  async logout(res: Response) {
    res
      .clearCookie("token")
      .send({ success: true, message: "logged out successfully" });
  }

  async myProfile(req): Promise<any> {
    try {
      const email = req.user.email;
      const userRole = req.user.userRole;
      if (userRole == ROLE.ADMIN) {
        throw new BadRequestException("Admin can not access");
      }
      const response = await this.usersCorporateRepository
        .createQueryBuilder("c")
        .where({ email: email })
        .select([
          "c.firstName",
          "c.lastName",
          "c.email",
          "c.age",
          "c.gender",
          "c.city",
          "c.country",
          "c.profileImage",
        ])
        .getOne();
      return this.validResponse.validateResponse(
        response,
        null,
        "user details successfully fonded"
      );
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async uploadProfileImage(file, req) {
    try {
      const email = req.user.email;
      const userRole = req.user.userRole;
      if (userRole == ROLE.ADMIN) {
        throw new BadRequestException("Admin can not access");
      }
      const s3Image: any = await this.s3Service.uploadFile(file);
      await this.usersCorporateRepository.update(
        { email: email },
        { profileImage: s3Image.Location }
      );
      return {
        succes: 200,
        Image: s3Image.Location,
        message: "profile image updated successfully",
      };
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async updateProfile(req, body: EditProfileDto): Promise<any> {
    try {
      const email = req.user.email;
      const userRole = req.user.userRole;
      if (userRole == ROLE.ADMIN) {
        throw new BadRequestException("Admin can not access");
      }
      const response = await this.usersCorporateRepository.update(
        { email: email },
        {
          firstName: body.firstName,
          lastName: body.lastName,
          age: body.age,
          gender: body.gender,
          city: body.city,
          country: body.country,
        }
      );
      return this.validResponse.validateResponse(
        response,
        null,
        "profile updated successfully"
      );
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async changePassword(req, body: SetPasswordDto): Promise<any> {
    try {
      const email = req.user.email;
      const userRole = req.user.userRole;
      if (userRole == ROLE.ADMIN) {
        throw new BadRequestException("Admin can not access");
      }
      const salt = await bcrypt.genSalt();
      const hashPassword = await bcrypt.hash(body.password, salt);
      const user = await this.usersCorporateRepository.findOne({
        where: { email: email },
      });

      if (body.currentPassword === body.password) {
        throw new BadRequestException(
          "current password and password cannot be same!"
        );
      }
      if (await bcrypt.compare(body.currentPassword, user.password)) {
        await this.usersCorporateRepository.update(
          { id: user.id },
          { password: hashPassword }
        );
        return { success: true, message: "Password changed successfully" };
      } else {
        throw new BadRequestException(
          "current password is not match in user database!"
        );
      }
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async userFavoriteSpecies(req) {
    try {
      const userId = req.user.userId;
      const userObj = await this.usersCorporateRepository.findOneBy({
        id: userId,
      });
      if (!userObj) {
        throw new BadRequestException("user does not exist");
      }
      const res1 = await this.speciesRepository.query(`select 
    s.id
    , s."speciesName"
    , fs2."isFavourite"
    , as2."url" as imagePath
    from species s 
    left join asset_species as2 
    on s.id = as2."speciesId" and as2."type" = 'coverImage'
    left join favourite_species fs2 on s.id = fs2."speciesId" and 
    fs2."userId" = '${userObj.id}'
    where s."isActive" = true `);

      let favSpecies = res1.filter((species) => species.isFavourite == true);
      let allSpecies = res1.filter((species) => species.isFavourite != true);

      return {
        favSpecies: favSpecies,
        allSpecies: allSpecies,
      };
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async donationHistory(
    req,
    limit: number,
    page: number,
    orderByDate: string,
    orderByProduct: string,
    orderByAmount: string
  ) {
    try {
      const userId = req.user.userId;
      let byWhat = "";
      if (orderByDate != "All") {
        byWhat += `"createdAt" ${orderByDate}`;
      } else if (orderByProduct != "All") {
        byWhat += `"productName" ${orderByProduct}`;
      } else if (orderByAmount != "All") {
        byWhat += `"amount" ${orderByAmount}`;
      } else {
        byWhat += `"createdAt" desc`;
      }
      const response = await this.paymentRepo
        .query(`select pt."createdAt", 'Species' as "type", s."speciesName" as "productName", pt."speciesId" as "productId", pt."paidCurrency",
        pt."paidAmount", as2.url  from payment_transactions pt 
        left join asset_species as2 on pt."speciesId" = as2."speciesId" 
        left join species s on s.id = pt."speciesId" 
        where pt."userId" = '${userId}' and as2."type" = 'coverImage' and pt.status = 'Success' and pt."speciesId" is not null 
        union all 
        select pt2."createdAt", 'Project' as "type", p."projectName" as "productName", pt2."projectId" as "productId", pt2."paidCurrency",
        pt2."paidAmount", ap.url from payment_transactions pt2 
        left join asset_projects ap on pt2."projectId" = ap."projectId" 
        left join projects p on p.id = pt2."projectId" 
        where pt2."userId" = '${userId}' and ap."type" = 'coverImage' and pt2.status = 'Success' and pt2."projectId" is not null
        union all 
        select pt3."createdAt", '5WF' as "type", '5WF' as "productName", null as "productId",
        pt3."paidCurrency", pt3."paidAmount", 'https://fivewfstaging.s3.ap-south-1.amazonaws.com/AdminLogo.jpg' as "url" 
        from payment_transactions pt3 where pt3."userId" = '${userId}'
        and pt3."is5WF" = true and pt3.status = 'Success' order by ${byWhat}`);

      let data = [...response];
      let result = [];
      if (!page) page = 1;
      if (!limit) {
        data.length < 4 ? (limit = data.length) : (limit = 4);
      }
      let pageSize = Math.ceil(data.length / limit);
      for (
        let i = (page - 1) * limit;
        i < page * limit && i < data.length;
        i++
      ) {
        result.push(data[i]);
      }
      if (result.length <= 0) {
        return {
          totalCount: data.length,
          data: data,
        };
      } else {
        return {
          totalCount: data.length,
          pageCount: pageSize,
          rowCount: result.length,
          data: result,
        };
      }
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async voteSpecies(req): Promise<any> {
    try {
      const speciesId = req.body.speciesId;
      const like = req.body.like;
      const userId = req.user.userId;
      const exist = await this.favouriteSpecies
        .query(`select fs2."userId" from favourite_species fs2 
            where fs2."userId" = '${userId}' and fs2."speciesId" = '${speciesId}'`);
      if (exist[0]) {
        if (like == true) {
          await this.favouriteSpecies
            .query(`update public.favourite_species fs2 
              set "isLiked" = true where fs2."userId" = '${userId}' 
              and fs2."speciesId" = '${speciesId}'`);
          await this.favouriteSpecies.query(
            `update species set "likesCount" = "likesCount" + 1 where id  = '${speciesId}'`
          );
        } else {
          await this.favouriteSpecies
            .query(`update public.favourite_species fs2 
          set "isLiked" = false where fs2."userId" = '${userId}' 
          and fs2."speciesId" = '${speciesId}'`);
          await this.favouriteSpecies.query(
            `update species set "likesCount" = "likesCount" - 1 where id  = '${speciesId}'`
          );
        }
      } else {
        await this.favouriteSpecies.query(`INSERT INTO public.favourite_species
      (id, "isFavourite", "userId", "speciesId", "isLiked")
      VALUES(uuid_generate_v4(), false, '${userId}', 
      '${speciesId}', true)`);
        await this.favouriteSpecies.query(
          `update species set "likesCount" = "likesCount" + 1 where id  = '${speciesId}'`
        );
      }
      return { succes: 200, message: "successful" };
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async voteProject(req): Promise<any> {
    try {
      const projectId = req.body.projectId;
      const like = req.body.like;
      const userId = req.user.userId;
      const exist = await this.favouriteProjects
        .query(`select fp."userId" from favourite_project fp 
      where fp."userId" = '${userId}' and fp."projectId" = '${projectId}'`);
      if (exist[0]) {
        if (like == true) {
          await this.favouriteProjects
            .query(`update favourite_project fp set "isLiked" = true where fp."userId" = '${userId}'
          and fp."projectId" = '${projectId}'`);
          await this.favouriteSpecies.query(
            `update projects set "likesCount" = "likesCount" + 1 where id = '${projectId}'`
          );
        } else {
          await this.favouriteProjects
            .query(`update favourite_project fp set "isLiked" = false where fp."userId" = '${userId}'
          and fp."projectId" = '${projectId}'`);
          await this.favouriteProjects.query(
            `update projects set "likesCount" = "likesCount" - 1 where id = '${projectId}'`
          );
        }
      } else {
        await this.favouriteProjects
          .query(`insert into favourite_project (id, "isFavourite", 
        "userId", "projectId", "isLiked") 
        values (uuid_generate_v4(), false, '${userId}', '${projectId}', true)`);
        await this.favouriteProjects.query(
          `update projects set "likesCount" = "likesCount" + 1 where id = '${projectId}'`
        );
      }
      return { succes: 200, message: "successful" };
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async voteForFavoriteSpecies(req) {
    try {
      const speciesId = req.body.speciesId;
      const favorite = req.body.favorite;
      const userId = req.user.userId;
      const exist = await this.favouriteSpecies
        .query(`select fs2."userId" from favourite_species fs2 
    where fs2."userId" = '${userId}' and fs2."speciesId" = '${speciesId}'`);
      console.log(exist);
      if (exist[0]) {
        if (favorite == true) {
          await this.favouriteSpecies
            .query(`update public.favourite_species fs2 
          set "isFavourite" = true where fs2."userId" = '${userId}' 
          and fs2."speciesId" = '${speciesId}'`);
        } else {
          await this.favouriteSpecies
            .query(`update public.favourite_species fs2 
          set "isFavourite" = false where fs2."userId" = '${userId}' 
          and fs2."speciesId" = '${speciesId}'`);
        }
      } else {
        await this.favouriteSpecies.query(`INSERT INTO public.favourite_species
      (id, "isFavourite", "userId", "speciesId", "isLiked")
      VALUES(uuid_generate_v4(), true, '${userId}', '${speciesId}', false)`);
      }
      return { succes: 200, message: "successful" };
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async speciesForLandingPage(token: string) {
    try {
      let who = "";
      let like = "";
      if (token) {
        const jwt = token.split(" ");
        const decodeHeader = await this.jwtService.verifyAsync(jwt[1], {
          secret: process.env.LOGIN_SECRET,
        });
        if (decodeHeader.userRole === "Admin") {
          throw new BadRequestException("Admin can not access");
        }
        who += `and fs2."userId" = '${decodeHeader.userId}'`;
        like += `, fs2."isLiked", fs2.carts`;
      }
      const landingPage = await this.usersCorporateRepository
        .query(`select * from (select s.id, s."speciesName",s."speciesNameScientific",
      s.category,s.overview,s."speciesDetails" ${like}, as2.url as "imageURL",
      (select count(nullif(fs3."isLiked",false))
      from favourite_species fs3 where s.id = fs3."speciesId" )as likes,
      row_number() over (partition by s.id) as rowNumber from species s 
      left join favourite_species fs2 on s.id = fs2."speciesId" ${who}
      left join asset_species as2 on s.id = as2."speciesId" 
      and as2."type" = 'coverImage' where s."isActive" = true
      order by s."createdAt" desc limit 3) as tempTable where tempTable.rowNumber = 1`);
      return this.validResponse.validateResponse(
        landingPage,
        null,
        "Successful"
      );
    } catch (error) {
      if (error.message == "invalid token") {
        throw new BadRequestException(
          "oops!, you are unauthorized or invalid token"
        );
      } else if (error.message == "jwt expired") {
        throw new BadRequestException("oops!, your session is expired");
      } else if (error.message == "invalid signature") {
        throw new BadRequestException(
          "oops!, your signup process is still pending or need to be logged in first"
        );
      } else {
        throw new BadRequestException({
          message: error.message,
          code: error.code,
        });
      }
    }
  }

  async projectsForLandingPage(token: string) {
    try {
      let who = "";
      let like = "";
      if (token) {
        const jwt = token.split(" ");
        const decodeHeader = await this.jwtService.verifyAsync(jwt[1], {
          secret: process.env.LOGIN_SECRET,
        });
        if (decodeHeader.userRole === "Admin") {
          throw new BadRequestException("Admin can not access");
        }
        who += `and '${decodeHeader.userId}' = fp."userId"`;
        like += `, fp."isLiked", fp.carts`;
      }
      const landingPage = await this.projectRepository
        .query(`select * from (select p.id , p."projectName" ,p.overview ,p."projectDetails"
       ${like}, ap.url as "imageURL" , 
    (select count(nullif(fp2."isLiked", false))
    from favourite_project fp2 where p.id = fp2."projectId") as likes,
    row_number() over (partition by p.id) as rowNumber from projects p 
    left join favourite_project fp on p.id = fp."projectId" ${who}
    left join asset_projects ap on p.id = ap."projectId" and ap."type" = 'coverImage'
    where p."isActive" = true
    order by p."createdAt" desc limit 3) as tempTable where tempTable.rowNumber = 1`);
      return this.validResponse.validateResponse(
        landingPage,
        null,
        "Successful"
      );
    } catch (error) {
      if (error.message == "invalid token") {
        throw new BadRequestException(
          "oops!, you are unauthorized or invalid token"
        );
      } else if (error.message == "jwt expired") {
        throw new BadRequestException("oops!, your session is expired");
      } else if (error.message == "invalid signature") {
        throw new BadRequestException(
          "oops!, your signup process is still pending or need to be logged in first"
        );
      } else {
        throw new BadRequestException({
          message: error.message,
          code: error.code,
        });
      }
    }
  }

  async oceanProjectsForLandingPage(token: string) {
    try {
      let who = "";
      let like = "";
      if (token) {
        const jwt = token.split(" ");
        const decodeHeader = await this.jwtService.verifyAsync(jwt[1], {
          secret: process.env.LOGIN_SECRET,
        });
        if (decodeHeader.userRole === "Admin") {
          throw new BadRequestException("Admin can not access");
        }
        who += `and '${decodeHeader.userId}' = fp."userId"`;
        like += `, fp."isLiked", fp.carts`;
      }
      const landingPage = await this.projectRepository
        .query(`select * from (select p.id , p."projectName" ,p.overview ,p."projectDetails"
       ${like}, ap.url as "imageURL" ,
    (select count(nullif(fp2."isLiked", false))
    from favourite_project fp2 where p.id = fp2."projectId") as likes,
    row_number() over (partition by p.id) as rowNumber from projects p 
    left join favourite_project fp on p.id = fp."projectId" ${who}
    left join asset_projects ap on p.id = ap."projectId" and ap."type" = 'coverImage'
    where p."isActive" = true and p."isOcean" = true
    order by p."createdAt" desc) as tempTable where tempTable.rowNumber = 1`);
      return this.validResponse.validateResponse(
        landingPage,
        null,
        "Successful"
      );
    } catch (error) {
      if (error.message == "invalid token") {
        throw new BadRequestException(
          "oops!, you are unauthorized or invalid token"
        );
      } else if (error.message == "jwt expired") {
        throw new BadRequestException("oops!, your session is expired");
      } else if (error.message == "invalid signature") {
        throw new BadRequestException(
          "oops!, your signup process is still pending or need to be logged in first"
        );
      } else {
        throw new BadRequestException({
          message: error.message,
          code: error.code,
        });
      }
    }
  }

  async getUserOrCorporate(where: any): Promise<UsersCorporates> {
    try {
      let found;
      if (where.email) {
        found = await this.usersCorporateRepository.findOneBy({
          email: where.email,
        });
      } else if (where.companyName) {
        found = await this.usersCorporateRepository.findOneBy({
          companyName: where.companyName,
        });
      }
      return found;
    } catch (error) {
      throw new BadRequestException("User does not exist");
    }
  }

  async getDonation(req, pageNo, limit): Promise<any> {
    const userId = req.user.userId;
    try {
      const user = await this.usersCorporateRepository.findOne({
        where: { id: userId },
      });
      if (!user) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            message: "User not found!",
          },
          HttpStatus.BAD_REQUEST
        );
      }
      if (!pageNo) {
        pageNo = 1;
      }

      const queryData = `
        select 
        s."id",
        'Species' as "type",
        s."speciesName" as name,
        s."speciesNameScientific" as "scientificName",
        s.category,
        as2.url 
        from favourite_species fs2
        join species s 
        on fs2."speciesId" = s.id 
        inner join asset_species as2
        on as2."speciesId" = s.id 
        where fs2."userId" = '${user.id}' and as2."type" = 'speciesProfile' and fs2.carts = true 
        union all 
        select
        p."id",
        'Project' as "type",
        p."projectName" as name,
        s2."speciesName" as "projectScientificName",
        s2.category,
        ap.url 
        from favourite_project fp 
        join projects p 
        on fp."projectId" = p.id 
        inner join asset_projects ap 
        on ap."projectId" = p.id 
        left join species s2
        on p."speciesId" = s2.id 
        where fp."userId" = '${user.id}' and ap."type" = 'projectProfile' and fp.carts = true
        `;
      const data1 = await this.favouriteSpecies.query(queryData);
      const data = [...data1];
      let result = [];
      if (!limit) {
        data.length < 5 ? (limit = data.length) : (limit = 5);
      }
      const pageSize = Math.ceil(data.length / limit);
      for (
        let i = (pageNo - 1) * limit;
        i < pageNo * limit && i < data.length;
        i++
      ) {
        result.push(data[i]);
      }
      return {
        pageCount: pageSize,
        rowCount: result.length,
        totalCount: data.length,
        data: result,
      };
    } catch (error) {
      console.log(error);
      throw new BadRequestException(error.response);
    }
  }

  async addDonation(body: createDonation, req): Promise<any> {
    try {
      const { id, type } = body;
      const user = await this.usersCorporateRepository.findOne({
        where: { id: req.user.userId },
      });
      if (!user) {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            message: "User not found!",
          },
          HttpStatus.BAD_REQUEST
        );
      }
      if (type == "Species") {
        const exist = await this.speciesRepository.query(
          `select s.id from species s where id = '${id}'`
        );

        if (exist[0]) {
          console.log("update log");
          const fetch = await this.favouriteSpecies
            .query(`select id from favourite_species where "userId" = '${user.id}' and "speciesId" = '${id}' 
            `);
          if (fetch[0]) {
            await this.favouriteSpecies.query(`UPDATE public.favourite_species
              SET carts= true
              WHERE "speciesId" = '${id}' and "userId" = '${user.id}'
              `);
          } else {
            await this.favouriteSpecies
              .query(`INSERT INTO public.favourite_species
              (id, "isFavourite", "userId", "speciesId", "isLiked", carts)
              VALUES(uuid_generate_v4(), false, '${user.id}', '${id}', false, true)
              `);
          }
        } else {
          throw new HttpException(
            {
              status: HttpStatus.BAD_REQUEST,
              message: "species not found!",
            },
            HttpStatus.BAD_REQUEST
          );
        }
        return {
          status: true,
          message: "Successfully added to Your Profile",
        };
      }
      if (type === "Project") {
        const exist = await this.projectRepository.query(
          `select id from projects where id = '${id}'`
        );
        if (exist[0]) {
          const fetch = await this.favouriteProjects.query(`
            select * from favourite_project fp where fp."projectId" = '${id}'
            and fp."userId" = '${user.id}'
            `);
          if (fetch[0]) {
            await this.favouriteProjects.query(`UPDATE public.favourite_project
              SET carts= true
              WHERE "projectId" = '${id}' and "userId" = '${user.id}'
              `);
          } else {
            await this.favouriteProjects
              .query(`INSERT INTO public.favourite_project
              (id, "isFavourite", "userId", "projectId", "isLiked", carts)
              VALUES(uuid_generate_v4(), false, '${user.id}', '${id}', false, true);
              `);
          }
        } else {
          throw new HttpException(
            {
              status: HttpStatus.BAD_REQUEST,
              message: "project not found!",
            },
            HttpStatus.BAD_REQUEST
          );
        }
        return {
          status: true,
          message: "Successfully added to Your Profile",
        };
      }
    } catch (error) {
      console.log(error);
      throw new BadRequestException(error.message);
    }
  }

  async removeDonation(req, id: string, type: string): Promise<any> {
    try {
      const user = await this.usersCorporateRepository.findOne({
        where: { id: req.user.userId },
      });
      if (!user) {
        throw new BadRequestException("User does not exist");
      }
      if (type === "Species") {
        const donationSpecies = await this.favouriteSpecies
          .query(`select fs2."userId" from favourite_species fs2 
          where fs2."userId" = '${user.id}' and fs2."speciesId" = '${id}'`);

        if (donationSpecies) {
          await this.favouriteSpecies.query(`UPDATE public.favourite_species
            SET carts= false
            WHERE "speciesId" = '${id}' and "userId" = '${user.id}'
            `);
          return {
            status: true,
            message: "species removed successfully",
          };
        }
      }

      if (type === "Project") {
        const donationProject = await this.favouriteProjects
          .query(`select fs2."userId" from favourite_project fs2 
          where fs2."userId" = '${user.id}' and fs2."projectId" = '${id}'`);

        if (donationProject) {
          await this.favouriteProjects.query(`UPDATE public.favourite_project
            SET carts= false
            WHERE "projectId" = '${id}' and "userId" = '${user.id}'
            `);
          return {
            status: true,
            message: "project removed successfully",
          };
        }
      }
    } catch (error) {
      console.log(error);
      throw new BadRequestException(error.response);
    }
  }

  async getCountry() {
    try {
      const country = this.getCountryAPI.getAllCountries();

      return {
        success: true,
        country: country,
      };
    } catch (error) {
      throw new BadRequestException(error.response);
    }
  }
}
