import { Injectable } from "@nestjs/common";

@Injectable()
export class paymentEmailReceipt {
  constructor() {}
  async paymentReceipt(
    orderId: string,
    Items: string,
    statusImg: string,
    paidCurrency: string,
    totalAmount: number
  ) {
    return `<!DOCTYPE html>
    <html>
    
    <head>
      <meta charset="utf-8" />
      <meta http-equiv="x-ua-compatible" content="ie=edge" />
      <title>Email Receipt</title>
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
      <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;700&display=swap" rel="stylesheet" />
      <style type="text/css">
        * {
          font-family: "Noto Sans", sans-serif;
          box-sizing: border-box;
        }
    
        body {
          width: 100% !important;
          height: 100% !important;
          padding: 0 !important;
          margin: 0 !important;
        }
    
        table {
          border-collapse: collapse !important;
          color: black;
        }
    
        table td {
          padding: 10px 20px;
          word-break: break-all;
        }
    
        a {
          color: #1a82e2;
        }
    
        img {
          height: auto;
          line-height: 100%;
          text-decoration: none;
          border: 0;
          outline: none;
        }
    
        .f14 {
          font-size: 15px;
          font-weight: 300;
          color: black;
        }
    
        .m25 {
          margin: 25px 0px;
        }
    
        .backgroundWrapper {
          background-color: white;
          border-radius: 10px;
          margin: 0 auto;
          min-width: 300px;
          width: 100%;
          max-width: 768px;
          padding: 20px;
        }
    
        .justifyCenterClass {
          text-align: center;
        }
    
        .justifyFlexClass {
          display: flex;
          gap: 5px;
          width: 100%;
          padding: 10px 0px;
        }
    
        .justifyFlexClass span {
          color: #666;
        }
    
        .headerRow {
          background-color: lightgray;
        }
    
        .alignLeftClass {
          text-align: left;
          width: 100%;
          padding: 10px 0px;
        }
    
        .boldWeight {
          font-weight: 700;
        }
    
        .logo {
          width: 48px;
          max-width: 48px;
          min-width: 48px;
          margin-top: 15px;
        }
    
        .statusImg {
          width: 100px;
          max-width: 100px;
          min-width: 100px;
        }
    
        @media only screen and (min-width: 320px) and (max-width: 767px) {
    
          thead {
            display: none;
          }
    
          tr {
            display: block;
            border: 1px solid gainsboro;
            margin: 1em 0;
            padding: 0.5em;
          }
    
          td {
            display: table-row;
            border: none !important;
          }
    
          td::before {
            content: attr(data-label) ":";
            font-weight: bold;
            display: table-cell;
            text-align: right;
            padding: 0 5px 0 10px;
            white-space: nowrap;
            width: 1px;
          }
    
          tfoot tr td:first-child {
            display: none;
          }
        }
      </style>
    </head>
    
    <body style="background-color: #d2c7ba">
      <div class="preheader" style="
              display: none;
              max-width: 0;
              max-height: 0;
              overflow: hidden;
              font-size: 1px;
              line-height: 1px;
              color: #fff;
              opacity: 0;
            ">
        A preheader is the short summary text that follows the subject line when
        an email is viewed in the inbox.
      </div>
      <div class="justifyCenterClass m25">
        <a href="https://stage-app.5wf.org" target="_blank">
          <img src="https://fivewfstaging.s3.ap-south-1.amazonaws.com/updated-logo.png" alt="Logo" class="logo" />
        </a>
      </div>
      <div class="backgroundWrapper">
        ${statusImg}
        <h1 class="justifyCenterClass">
          Thank you for your donation!
        </h1>
        <div class="justifyFlexClass">
          <div class="boldWeight" data-label="Order #">Order :</div>
          <span class="boldWeight" align="right" data-label="orderId">${orderId}</span>
        </div>
        <table border="0" cellpadding="0" cellspacing="0" width="100%">
          <thead>
            <tr class="headerRow">
              <td class="boldWeight" data-label="Product Name">Product Name</td>
              <td class="boldWeight" align="right" data-label="Amount">Amount</td>
            </tr>
          </thead>
          <tbody>
            ${Items}
          </tbody>
          <tfoot>
            <tr>
              <td
                style="padding: 12px;font-size: 16px;line-height: 24px;border-top: 2px dashed #d2c7ba;border-bottom: 2px dashed #d2c7ba;">
                <strong>Total Amount</strong>
              </td>
              <td data-label="Total Amount" align="right"
                style="padding: 12px;font-size: 16px;line-height: 24px;border-top: 2px dashed #d2c7ba;border-bottom: 2px dashed #d2c7ba">
                <strong>${paidCurrency.toUpperCase()} ${totalAmount}</strong>
              </td>
            </tr>
          </tfoot>
        </table>
        <div class="f14 alignLeftClass">
          If you have any questions, please
          <a style="text-decoration: none" href="mailto:info@5wf.org">contact us</a>, or get in touch on Twitter
          <a style="text-decoration: none" href="https://twitter.com/5WFoundation">@5wfoundation</a>.
        </div>
        <div class="f14 alignLeftClass">
          Best regards<br />
          <b>5W Foundation</b>
        </div>
        <div>
          <div class="alignLeftClass" style="font-size: 14px; line-height: 20px; color: #666">
            <p style="font-size: 9pt; color: grey; margin-top: 15px">
              <i>
                ©Copyright 2020 Stichting 5W Foundation. All rights reserved.
                Various divademarks held by their respective owners. Postal: PO
                Box 78049, 1070LP Amsterdam, North Holland, Netherlands | KvK:
                85846759 | RSIN: 863764939
              </i>
            </p>
          </div>
        </div>
      </div>
    </body>
    
    </html>`;
  }
}
