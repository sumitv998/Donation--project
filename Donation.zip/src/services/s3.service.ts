import { Injectable } from "@nestjs/common";
import * as AWS from "aws-sdk";

@Injectable()
export class S3Service {
  AWS_S3_BUCKET = process.env.AWS_S3_BUCKET;
  s3 = new AWS.S3({
    accessKeyId: process.env.ACCESS_KEY,
    secretAccessKey: process.env.KEY_SECRET,
  });

  async uploadFile(file: any) {
    const { originalname } = file;
    const uploadData = await this.s3_upload(
      file.buffer,
      this.AWS_S3_BUCKET,
      originalname,
      file.mimetype
    );
    return uploadData;
  }

  async s3_upload(file, bucket, name, mimetype) {
    const params = {
      Bucket: bucket,
      Key: String(name),
      Body: file,
      ACL: "public-read",
      ContentType: mimetype,
      ContentDisposition: "inline",
      CreateBucketConfiguration: {
        LocationConstraint: process.env.BUCKET_REAGION,
      },
    };
    try {
      let s3Response = await this.s3.upload(params).promise();
      // console.log(s3Response);
      return s3Response;
    } catch (e) {
      console.log(e);
    }
  }

  async uploadJsonFile(obj: any, filename:string) {
    const data = {
      Bucket: this.AWS_S3_BUCKET,
      Key: `${filename}.json`,
      Body: obj,
      ContentEncoding: "base64",
      ContentType: "application/json",
      ACL: "public-read",
    };
    try {
      let s3Response = await this.s3.upload(data).promise();
      // console.log(s3Response);
      return s3Response;
    } catch (e) {
      console.log(e);
    }
  }
}
