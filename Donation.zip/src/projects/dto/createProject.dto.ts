import { uuid } from "aws-sdk/clients/customerprofiles";
import {
  ArrayMinSize,
  IsArray,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
} from "class-validator";
import { GEOGRAPHICREGION, Species } from "src/species/entities/species.entity";
import { CONSERVATIONACTIVITY } from "../entities/project.entity";

export class CreateProjectDto {
  @IsOptional()
  coverImage: string;

  @IsString()
  @IsNotEmpty()
  projectName: string;

  @IsString()
  @IsNotEmpty()
  @IsEnum(GEOGRAPHICREGION)
  geographicRegion: GEOGRAPHICREGION;

  @IsNotEmpty()
  species: Species;

  @IsString()
  @IsNotEmpty()
  @IsEnum(CONSERVATIONACTIVITY)
  conservationActivity: CONSERVATIONACTIVITY;

  @IsString()
  @IsOptional()
  overview: string;

  @IsOptional()
  projectDetails: string;

  @IsOptional()
  projectBenifit: string;

  @IsOptional()
  isOcean: boolean;

  @IsOptional()
  projectVideo: string;

  @IsOptional()
  images: [];

  @IsOptional()
  projectProfile: string;
}
