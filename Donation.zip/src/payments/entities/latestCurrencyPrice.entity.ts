import { ApiProperty } from "@nestjs/swagger";
import { Column, Double, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class LatestCurrencyPrice {
  @ApiProperty()
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  USD: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  EUR: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  GBP: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  AED: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  CAD: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  AUD: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  HKD: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  INR: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  JPY: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  SGD: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  ZAR: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  CHF: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 1, nullable: true })
  BTC: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  ETH: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  XRP: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  DOGE: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  SOL: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  ADA: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  HBAR: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  LTC: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  DASH: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  BCH: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  ZEC: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  XLM: Double;
}
