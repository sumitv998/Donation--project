import { Injectable } from "@nestjs/common";
import * as sgMail from "@sendgrid/mail";

require("dotenv").config();
@Injectable()
export class SendGridEmailService {
  constructor() {
    sgMail.setApiKey(process.env.SENDGRID_API_KEY);
  }

  async sendEmail(email: string, subject: string, message: string) {
    const msg = {
      to: email,
      from: process.env.EMAIL_AUTH_USER,
      subject: subject,
      text: "and easy to do anywhere, even with Node.js",
      html: message,
    };
    sgMail
      .send(msg)
      .then((response) => {})
      .catch((error) => {});
  }
}
