export interface AuthJwtPayload {
  userId?: string;
  email?: string;
  userRole?: string;
}
