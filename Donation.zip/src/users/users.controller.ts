import {
  Body,
  Controller,
  Get,
  Inject,
  Put,
  Post,
  Req,
  Res,
  Headers,
  UploadedFile,
  ParseFilePipeBuilder,
  HttpStatus,
  UseInterceptors,
  UseGuards,
  Query,
} from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { FileInterceptor } from "@nestjs/platform-express";
import { Response, Request } from "express";
import { JwtAuthGuard } from "src/guards/jwt.guard";
import { fileValidation, imageValidation } from "../services/filesValidation";
import {
  CATEGORY,
  GEOGRAPHICREGION,
  HABITATETYPE,
} from "src/species/entities/species.entity";
import { CreateCorporateDto } from "./dto/createCorporate.dto";
import { CreateUserDto } from "./dto/createUser.dto";
import { EditProfileDto } from "./dto/editProfile.dto";
import { ForgortPaaswordDto } from "./dto/forgotPassword.dto";
import { SetPasswordDto } from "./dto/setPassword.dto";
import { LoginDto } from "./dto/userLogin.dto";
import { ROLE, UsersCorporates } from "./entities/usersCorporate.entity";
import { UsersService } from "./users.service";
import { SPECIESNAME } from "./dto/speciesDashboard.dto";
import { PROJECTNAME } from "./dto/projectDashboard.dto";
import { CONSERVATIONACTIVITY } from "src/projects/entities/project.entity";
import { createDonation } from "src/favourite/dto/createDonation.dto";
import RolesGuard from "src/guards/role.guard";

// import { Roles } from "src/decorator/roles.decorator";
// import { RolesGuard } from "src/guards/role.guard";

@Controller("users")
export class UsersController {
  constructor(private readonly jwtService: JwtService) {}
  @Inject(UsersService) private readonly userService: UsersService;

  @Post("/verifyEmail")
  verifyEmail(@Req() req: Request): Promise<any> {
    return this.userService.verifyEmail(req);
  }

  @Post("/createPassword")
  createPassword(
    @Headers("Authorization") token: string,
    @Body() body: SetPasswordDto
  ): Promise<any> {
    return this.userService.createPassword(token, body);
  }

  @Post("/userProfile")
  userProfile(
    @Headers() token,
    @Body() createUserDto: CreateUserDto
  ): Promise<void | UsersCorporates> {
    return this.userService.userProfile(token.authorization, createUserDto);
  }

  @Post("/corporateProfile")
  corporateProfile(
    @Headers() token,
    @Body() createCorporateDto: CreateCorporateDto
  ): Promise<void | UsersCorporates> {
    return this.userService.corporateProfile(
      token.authorization,
      createCorporateDto
    );
  }

  @Get("/speciesForFavorite")
  speciesForFavorite(): Promise<any> {
    return this.userService.speciesForFavorite();
  }

  @Post("/login")
  login(
    @Body() body: LoginDto,
    @Res({ passthrough: true }) res: Response
  ): Promise<any> {
    return this.userService.login(body, res);
  }

  @Get("/dashboardForSpecies")
  dashboardForSpecies(
    @Headers() token,
    @Query("speciesName") speciesName: SPECIESNAME,
    @Query("IUCNRedList") IUCNRedList: CATEGORY,
    @Query("habitateType") habitateType: HABITATETYPE,
    @Query("geographicRegion") geographicRegion: GEOGRAPHICREGION,
    @Query("key") key: string,
    @Query("page") page: number,
    @Query("limit") limit: number
  ): Promise<any> {
    return this.userService.dashboardForSpecies(
      token.authorization,
      speciesName,
      IUCNRedList,
      habitateType,
      geographicRegion,
      key,
      page,
      limit
    );
  }

  @Get("/dashboardForProjects")
  dashboardForProjects(
    @Headers() token,
    @Query("projectName") projectName: PROJECTNAME,
    @Query("geographicRegion") geographicRegion: GEOGRAPHICREGION,
    @Query("conservationActivity") conservationActivity: CONSERVATIONACTIVITY,
    @Query("key") key: string,
    @Query("page") page: number,
    @Query("limit") limit: number
  ): Promise<any> {
    return this.userService.dashboardForProjects(
      token.authorization,
      projectName,
      geographicRegion,
      conservationActivity,
      key,
      page,
      limit
    );
  }

  @Get("/speciesDetails")
  speciesDetails(
    @Headers() token,
    @Query("speciesId") speciesId: string,
    @Req() req
  ) {
    return this.userService.speciesDetails(token.authorization, speciesId, req);
  }

  @Get("/projectDetails")
  projectDetails(
    @Headers() token,
    @Query("projectId") projectId: string,
    @Req() req
  ) {
    return this.userService.projectDetails(token.authorization, projectId, req);
  }

  @Post("/forgotPassword")
  forgotPassword(@Body() body: ForgortPaaswordDto) {
    return this.userService.forgotPassword(body);
  }

  @Post("/logout")
  logout(@Res({ passthrough: true }) res: Response): Promise<any> {
    return this.userService.logout(res);
  }

  @UseGuards(JwtAuthGuard, RolesGuard())
  @Post("/voteSpecies")
  async voteSpecies(@Req() req) {
    return this.userService.voteSpecies(req);
  }

  @UseGuards(JwtAuthGuard, RolesGuard())
  @Post("/voteProject")
  async voteProject(@Req() req) {
    return this.userService.voteProject(req);
  }

  @UseGuards(JwtAuthGuard, RolesGuard())
  @Get("/myProfile")
  myProfile(@Req() req): Promise<any> {
    return this.userService.myProfile(req);
  }

  @UseGuards(JwtAuthGuard, RolesGuard())
  @Put("/updateProfile")
  updateProfile(@Req() req, @Body() body: EditProfileDto): Promise<any> {
    return this.userService.updateProfile(req, body);
  }

  @UseGuards(JwtAuthGuard, RolesGuard())
  @Put("/uploadImage")
  @UseInterceptors(FileInterceptor("image", fileValidation))
  uploadProfileImage(
    @UploadedFile(
      new ParseFilePipeBuilder()
        .addMaxSizeValidator({ maxSize: 5000000 })
        .build({ errorHttpStatusCode: HttpStatus.UNPROCESSABLE_ENTITY })
    )
    file: Express.Multer.File,
    @Req() req
  ) {
    return this.userService.uploadProfileImage(file, req);
  }

  @UseGuards(JwtAuthGuard, RolesGuard())
  @Put("/changePassword")
  changePassword(@Req() req, @Body() body: SetPasswordDto): Promise<any> {
    return this.userService.changePassword(req, body);
  }

  @UseGuards(JwtAuthGuard, RolesGuard())
  @Get("/userFavoriteSpecies")
  userFavoriteSpecies(@Req() req) {
    return this.userService.userFavoriteSpecies(req);
  }

  @UseGuards(JwtAuthGuard, RolesGuard())
  @Get("/donationHistory")
  donationHistory(
    @Req() req,
    @Query("limit") limit: number,
    @Query("page") page: number,
    @Query("orderByDate") orderByDate: string,
    @Query("orderByProduct") orderByProduct: string,
    @Query("orderByAmount") orderByAmount: string
  ) {
    return this.userService.donationHistory(
      req,
      limit,
      page,
      orderByDate,
      orderByProduct,
      orderByAmount
    );
  }

  @UseGuards(JwtAuthGuard, RolesGuard())
  @Post("/voteForFavoriteSpecies")
  voteForFavoriteSpecies(@Req() req) {
    return this.userService.voteForFavoriteSpecies(req);
  }

  @Get("/speciesForLandingPage")
  speciesForLandingPage(@Headers() token) {
    return this.userService.speciesForLandingPage(token.authorization);
  }

  @Get("/projectsForLandingPage")
  projectsForLandingPage(@Headers() token) {
    return this.userService.projectsForLandingPage(token.authorization);
  }

  @Get("/oceanProjectsForLandingPage")
  oceanProjectsForLandingPage(@Headers() token) {
    return this.userService.oceanProjectsForLandingPage(token.authorization);
  }

  @UseGuards(JwtAuthGuard, RolesGuard())
  @Post("/addDonation")
  addDonation(@Body() body: createDonation, @Req() req) {
    return this.userService.addDonation(body, req);
  }

  @UseGuards(JwtAuthGuard, RolesGuard())
  @Get("/donation")
  getDonation(
    @Req() req,
    @Query("pageNo") pageNo: number,
    @Query("limit") limit: number
  ) {
    return this.userService.getDonation(req, pageNo, limit);
  }

  @UseGuards(JwtAuthGuard, RolesGuard())
  @Post("/removedonation")
  removeDonation(@Body("id") id, @Body("type") type, @Req() req) {
    return this.userService.removeDonation(req, id, type);
  }

  @Get("/getCountry")
  getCountry() {
    return this.userService.getCountry();
  }
}
