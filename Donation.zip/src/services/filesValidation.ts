import { HttpException, HttpStatus } from "@nestjs/common";

export const imageValidation = {
  fileFilter: (req, file, cb) => {
    const filetypes =
      /jpeg|jpg|png|mp4|mov|avi|mpeg4|JPEG|JPG|PNG|MP4|MOV|AVI|MPEG4$/;
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test(file.originalname);

    if (mimetype && extname) {
      cb(null, true);
    } else {
      cb(
        new HttpException(
          "Note: file should be an image or video, please upload an image",
          HttpStatus.NOT_FOUND
        )
      );
    }
  },
};

export const fileValidation = {
  fileFilter: (req, file, cb) => {
    const filetypes = /jpeg|jpg|png|JPEG|JPG|PNG$/;
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test(file.originalname);
    if (mimetype && extname) {
      cb(null, true);
    } else {
      cb(
        new HttpException(
          `Image must be in ${filetypes} format only`,
          HttpStatus.NOT_FOUND
        )
      );
    }
  },
};

export const KYCfileValidation = {
  fileFilter: (req, file, cb) => {
    const filetypes = /jpeg|jpg|png|JPEG|JPG|PNG|pdf$/;
    const mimetype = filetypes.test(file.mimetype);
    const extname = filetypes.test(file.originalname);
    if (mimetype && extname) {
      cb(null, true);
    } else {
      cb(
        new HttpException(
          `Document must be in ${filetypes} format only`,
          HttpStatus.NOT_FOUND
        )
      );
    }
  },
};
