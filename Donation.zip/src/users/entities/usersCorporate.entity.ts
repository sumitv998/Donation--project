import { ApiProperty } from "@nestjs/swagger";
import { Species } from "../../species/entities/species.entity";
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  JoinTable,
  ManyToMany,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";
import { favouriteSpecies } from "src/favourite/entities/favSpecies.entity";
import { favouriteProject } from "src/favourite/entities/favProjects.entity";
import { paymentTransactions } from "src/payments/entities/payments.entity";

@Entity()
export class UsersCorporates {
  @PrimaryGeneratedColumn("uuid")
  public id: string;

  @ApiProperty()
  @Column({ type: "varchar" })
  public userRole: ROLE;

  // Corporate user entity
  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  public companyName: string;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  public sector: string;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  public representativeName: string;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  public position: string;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  public representativeEmail: string;

  //   Individual user entity
  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  public firstName: string;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  public lastName: string;

  @ApiProperty()
  @Column({ type: "int4", nullable: true })
  public age: number;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  public gender: GENDER;

  //   Common for both individual user and corporate user
  @ApiProperty()
  @Column({ type: "varchar", nullable: true, unique: true })
  email: string;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  password: string;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  public city: string;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  public country: string;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  passToken: string;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  public profileImage: object;

  @ApiProperty()
  @Column({ type: "boolean", default: false })
  public isVerified: boolean;

  @ApiProperty()
  @CreateDateColumn({ type: "timestamp" })
  public createdAt: Date;

  @ApiProperty()
  @UpdateDateColumn({ type: "timestamp" })
  public updateAt: Date;

  @OneToMany(
    () => favouriteSpecies,
    (favSpecies: favouriteSpecies) => favSpecies.user
  )
  favSpecies: favouriteSpecies[];

  @OneToMany(
    () => favouriteProject,
    (favProject: favouriteProject) => favProject.user
  )
  favProject: favouriteProject[];

  @OneToMany(
    () => paymentTransactions,
    (userTransaction: paymentTransactions) => userTransaction.user
  )
  userTransaction: paymentTransactions[];

  // @ManyToMany(() => Species, (species: Species) => species.user)
  // public species: Species[];

  // @ManyToMany(() => Projects, (project) => project.users)
  // public projects: Projects[];
}

export enum GENDER {
  MALE = "Male",
  FEMALE = "Female",
  TRANSGENDER = "Other",
  NOT_CONFIRM = "Dont want to say",
}

export enum ROLE {
  USER = "User",
  CORPORATE = "Corporate",
  ADMIN = "Admin",
}
