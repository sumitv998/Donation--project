import { IsOptional } from "class-validator";


export class UpdateProfileDto {
      
  @IsOptional()
  speciesProfile: string;
}
 