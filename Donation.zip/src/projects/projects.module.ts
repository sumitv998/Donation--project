import { Module } from '@nestjs/common';
import { ProjectsService } from './projects.service';
import { ProjectsController } from './projects.controller';
import { S3Service } from 'src/services/s3.service';
import { Projects } from './entities/project.entity';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AssetProjects } from './entities/assetsProject.entity';
import { JwtModule } from '@nestjs/jwt';

@Module({
  imports: [
    JwtModule.register({
      secret: process.env.ADMIN_JWT_SECRET,
      signOptions: {
        expiresIn: "24h",
      },
    }),
    TypeOrmModule.forFeature([Projects,AssetProjects]),
  ],
  controllers: [ProjectsController],
  providers: [ProjectsService, S3Service],
})
export class ProjectsModule {}
