import { ApiProperty } from "@nestjs/swagger";
import { Species } from "src/species/entities/species.entity";
import { UsersCorporates } from "src/users/entities/usersCorporate.entity";
import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryColumn,
  PrimaryGeneratedColumn,
} from "typeorm";

@Entity()
export class favouriteSpecies {
  @PrimaryGeneratedColumn("uuid")
  public id: string;

  @ApiProperty()
  @Column({ default: false, type: "boolean", nullable: true })
  isFavourite: boolean;

  @ApiProperty()
  @Column({ default: false, type: "boolean", nullable: true })
  isLiked: boolean;

  @ApiProperty()
  @Column({ default: false, type: "boolean", nullable: false })
  carts: boolean;

  @ManyToOne(
    () => UsersCorporates,
    (users: UsersCorporates) => users.favSpecies
  )
  @JoinColumn({ name: "userId" })
  user: UsersCorporates;

  @ManyToOne(() => Species, (species: Species) => species.favSpecies)
  @JoinColumn({ name: "speciesId" })
  species: Species;
}
