import { BadRequestException, Injectable, Res } from "@nestjs/common";
import { PassportStrategy } from "@nestjs/passport";
import { InjectRepository } from "@nestjs/typeorm";
import { ExtractJwt, Strategy } from "passport-jwt";
import { UsersCorporates } from "src/users/entities/usersCorporate.entity";
import { Repository } from "typeorm";

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(
    @InjectRepository(UsersCorporates)
    private readonly usersCorporateRepository: Repository<UsersCorporates>
  ) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: process.env.LOGIN_SECRET,
    });
  }
  async validate(payload) {
    return {
      userId: payload.userId,
      userRole: payload.userRole,
      email: payload.email,
    };
  }
}
