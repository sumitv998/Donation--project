import { ValidationPipe } from "@nestjs/common";
import { HttpAdapterHost, NestFactory } from "@nestjs/core";
import { useContainer } from "class-validator";
import * as cookieParser from "cookie-parser";
import { AppModule } from "./app.module";
import { config } from "aws-sdk";
import rawBodyMiddleware from "./payments/interfaces/rawBody.middleware";
// import { NowPaymentService } from "./payments/nowPayments.service";
// import { PaymentsController } from "./payments/payments.controller";
// import { AllExceptionsFilter } from "./config/errors.filter";

async function bootstrap() {
  config.update({
    region: process.env.BUCKET_REAGION,
    accessKeyId: process.env.ACCESS_KEY,
    secretAccessKey: process.env.KEY_SECRET,
  });
  const app = await NestFactory.create(AppModule);
  const port = process.env.PORT || 3000;
  app.useGlobalPipes(new ValidationPipe());
  // const httpAdapter  = app.get(HttpAdapterHost);
  // app.useGlobalFilters(new AllExceptionsFilter(httpAdapter));
  useContainer(app.select(AppModule), { fallbackOnErrors: true });
  app.use(cookieParser());
  app.use(rawBodyMiddleware());
  app.enableCors({
    credentials: true,
    // origin: "*",
    origin: [
      "http://localhost:3000",
      "https://5wf.vercel.app",
      "https://admin-frontend-fvdl.vercel.app",
      "https://stage-app.5wf.org",
      "https://stage-admin.5wf.org",
    ],
  });
  app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE");
    res.header("Access-Control-Allow-Headers", "Content-Type, Accept");
    next();
  });
  await app.listen(port, async () => {
    console.log(`Application is running on port: ${port}`);
  });
}
bootstrap();
