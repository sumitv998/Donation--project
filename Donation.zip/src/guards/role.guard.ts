import {
  Injectable,
  CanActivate,
  ExecutionContext,
  Type,
  BadRequestException,
} from "@nestjs/common";
import { ROLE } from "src/users/entities/usersCorporate.entity";
import { JwtAuthGuard } from "./jwt.guard";

export function RolesGuard(): Type<CanActivate> {
  class RolesGuardMixin extends JwtAuthGuard {
    async canActivate(context: ExecutionContext) {
      const ctx = context.switchToHttp();
      const req = ctx.getRequest();
      const user = req.user;
      if (user && user.userRole) {
        if(user.userRole === ROLE.CORPORATE || user.userRole === ROLE.USER){
          return true;
        }else{
          throw new BadRequestException("Only individual and corporate users can access")
        }
      }
      return false;
    }
  }
  return RolesGuardMixin;
}

export default RolesGuard;
