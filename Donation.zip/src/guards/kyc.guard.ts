import {
  BadRequestException,
  Injectable,
  UnauthorizedException,
} from "@nestjs/common";
import { AuthGuard } from "@nestjs/passport";
import { JsonWebTokenError, TokenExpiredError } from "jsonwebtoken";

@Injectable()
export class KYCAuthGuard extends AuthGuard("kyc") {
  handleRequest(err: any, user: any, info: any, context: any, status: any) {
    if (!user) {
      throw new UnauthorizedException("Oops!, you are unauthorized");
    }
    if (info instanceof TokenExpiredError) {
      throw new BadRequestException("Oops!, your session is expired");
    }
    if (info instanceof JsonWebTokenError) {
      throw new UnauthorizedException("jwt token required");
    }
    return super.handleRequest(err, user, info, context, status);
  }
}
