import {
  BadRequestException,
  HttpException,
  HttpStatus,
  Injectable,
} from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { InjectRepository } from "@nestjs/typeorm";
import { S3Service } from "src/services/s3.service";
import { Species } from "src/species/entities/species.entity";
import { Repository } from "typeorm";
import { CreateProjectDto } from "./dto/createProject.dto";
import { AssetProjects } from "./entities/assetsProject.entity";
import { Projects } from "./entities/project.entity";

@Injectable()
export class ProjectsService {
  constructor(
    @InjectRepository(Projects)
    private projectRepository: Repository<Projects>,

    @InjectRepository(AssetProjects)
    private projectAssetsRepository: Repository<AssetProjects>,
    private s3service: S3Service,
    private jwtService: JwtService
  ) {}

  async createProject(
    createProjectsDto: CreateProjectDto,
    req
  ): Promise<Projects | Species | any> {
    try {
      if (req.user.userRole == "Admin") {
        const species = await this.projectRepository.create(createProjectsDto);
        const data = await this.projectRepository.save(species);
        console.log("Data--- Species uuid",data);
        if (!data) {
          throw new HttpException(
            "Please Provide species data!",
            HttpStatus.NOT_FOUND
          );
        }

        if (
          createProjectsDto.coverImage == null &&
          createProjectsDto.coverImage == undefined
        ) {
          createProjectsDto.coverImage == undefined;
        } else {
          let s3DataCoverImage: any = await this.s3service.uploadFile(
            createProjectsDto.coverImage[0]
          );
          await this.createAssest({
            projectId: data.id,
            url: s3DataCoverImage.Location,
            type: "coverImage",
          });
        }

        if (
          createProjectsDto.images == null &&
          createProjectsDto.images == undefined
        ) {
          createProjectsDto.images == undefined;
        } else {
          for (let j = 0; j < createProjectsDto.images.length; j++) {
            let s3Data: any = await this.s3service.uploadFile(
              createProjectsDto.images[j]
            );
            await this.createAssest({
              projectId: data.id,
              url: s3Data.Location,
              type: "images",
            });
          }
        }

        if (
          createProjectsDto.projectVideo == null &&
          createProjectsDto.projectVideo == undefined
        ) {
          createProjectsDto.projectVideo == undefined;
        } else {
          let s3DataProjectVideo: any = await this.s3service.uploadFile(
            createProjectsDto.projectVideo[0]
          );
          await this.createAssest({
            projectId: data.id,
            url: s3DataProjectVideo.Location,
            type: "projectVideo",
          });
        }

        if (
          createProjectsDto.projectProfile == null &&
          createProjectsDto.projectProfile == undefined
        ) {
          createProjectsDto.projectProfile == undefined;
        } else {
          let s3DataProjectProfile: any = await this.s3service.uploadFile(
            createProjectsDto.projectProfile[0]
          );
          await this.createAssest({
            projectId: data.id,
            url: s3DataProjectProfile.Location,
            type: "projectProfile",
          });
        }
        return {
          success: true,
          message: "Your Project was create Successfully",
        };
      } else {
        throw new HttpException(
          "Only Admin can create Project!",
          HttpStatus.BAD_REQUEST
        );
      }
    } catch (error) {
      throw new BadRequestException(error.response);
    }
  }

  async createAssest(body): Promise<AssetProjects | any> {
    const q = await this.projectAssetsRepository.create(body);
    await this.projectAssetsRepository.save(q);
  }

  // async uploadSpeciesProfile(file, id, req: Request) {
  //   const jwt = req.cookies["token"];
  //   if (!jwt) {
  //     throw new BadRequestException("please login");
  //   }
  //   await this.jwtService.verifyAsync(jwt, {
  //     secret: process.env.ADMIN_JWT_SECRET,
  //   });
  //   const projectId = await this.projectRepository.findOne({
  //     where: { id: id },
  //   });
  //   if (!projectId) {
  //     throw new HttpException("Project Id is not valid", HttpStatus.NOT_FOUND);
  //   }

  //   const s3Image: any = await this.s3service.uploadFile(file);
  //   await this.createAssest({
  //     projectId: projectId.id,
  //     url: s3Image.Location,
  //     type: "projectProfile",
  //   });
  //   return { succes: 200, message: "project profile uploaded successfully" };
  // }
}
