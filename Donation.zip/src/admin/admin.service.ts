import { BadRequestException, HttpStatus } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import * as bcrypt from "bcrypt";
import { HttpException } from "@nestjs/common";
import { Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { UsersCorporates } from "src/users/entities/usersCorporate.entity";
import { Repository } from "typeorm";
import { AdminLoginDto } from "./dto/admin.login.dto";
import { AuthJwtPayload } from "./jwt.auth.payload";
import { SendGridEmailService } from "src/services/sendgridEmail.service";
import { emailDto } from "./dto/mail.dto";
import { AdminPasswordSet } from "./dto/admin.forgetpassword.dto";
import { Species } from "src/species/entities/species.entity";
import { Projects } from "../projects/entities/project.entity";
import { paymentTransactions } from "src/payments/entities/payments.entity";
import { LatestCurrencyPrice } from "src/payments/entities/latestCurrencyPrice.entity";
import { TransactionService } from "src/payments/transaction.repo";
import { SpeciesRepository } from "src/species/species.repository";
import { mailFormat } from "./../config/mailFormat";

@Injectable()
export class AdminService {
  constructor(
    @InjectRepository(UsersCorporates)
    private userRepository: Repository<UsersCorporates>,
    @InjectRepository(Species)
    private speciesRep: Repository<Species>,
    @InjectRepository(Projects)
    private projectRep: Repository<Projects>,
    @InjectRepository(paymentTransactions)
    private paymentRep: Repository<paymentTransactions>,
    @InjectRepository(LatestCurrencyPrice)
    private readonly currencyPriceRepo: Repository<LatestCurrencyPrice>,
    private readonly transactionService: TransactionService,
    private readonly speciesRepoTransaction: SpeciesRepository,
    private jwtService: JwtService,
    private mailing: mailFormat,
    private readonly sendGridEmailService: SendGridEmailService
  ) {}

  async adminLogin(
    adminLoginDto: AdminLoginDto
  ): Promise<UsersCorporates | any> {
    try {
      const { email, password } = adminLoginDto;
      const user = await this.userRepository.findOne({
        where: { email: email },
      });
      if (!user) {
        throw new HttpException(
          {
            status: HttpStatus.NOT_FOUND,
            message: "User not found",
          },
          HttpStatus.NOT_FOUND
        );
      }
      if (user.userRole !== "Admin") {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            message: "Admin can access only access this pages!",
          },
          HttpStatus.BAD_REQUEST
        );
      }
      if (user && (await bcrypt.compare(password, user.password))) {
        const userId = user.id;
        const userRole = user.userRole;
        let payload: AuthJwtPayload = { userId, email, userRole };
        payload.userRole = user.userRole;
        const token = await this.jwtService.signAsync(payload, {
          secret: process.env.LOGIN_SECRET,
          expiresIn: "24h",
        });
        return {
          success: true,
          token: token,
          message: "Your are login now in Admin Panel!",
        };
      } else {
        throw new HttpException(
          {
            status: HttpStatus.UNAUTHORIZED,
            message: "Please check your login credentials",
          },
          HttpStatus.UNAUTHORIZED
        );
      }
    } catch (error) {
      throw new BadRequestException(error.response);
    }
  }

  async setPassword(req, adminPassword: AdminPasswordSet, token): Promise<any> {
    try {
      if (!token) {
        throw new BadRequestException("jwt token required");
      }
      const jwt = token.split(" ");
      const decodeHeader = await this.jwtService.verifyAsync(jwt[1], {
        secret: process.env.JWT_SECRET,
      });
      const { userRole, email } = decodeHeader;
      const { password, confirmPassword } = adminPassword;
      if (userRole == "Admin") {
        const user = await this.userRepository.findOne({
          where: { email: email },
        });
        if (password !== confirmPassword) {
          throw new HttpException(
            {
              status: HttpStatus.NOT_FOUND,
              message: "password and confirmPassword is not match",
            },
            HttpStatus.NOT_FOUND
          );
        }
        const salt = await bcrypt.genSalt();
        const hashPassword = await bcrypt.hash(password, salt);
        const dataCompare = await bcrypt.compare(password, user.password);
        if (dataCompare) {
          throw new HttpException(
            {
              status: HttpStatus.BAD_REQUEST,
              message: "password cannot be same to old password!",
            },
            HttpStatus.BAD_REQUEST
          );
        } else {
          user.password = hashPassword;
          await this.userRepository.save(user);
          return { success: true, message: "Password created successfully" };
        }
      } else {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            message: "This set passwaord for Admin only!",
          },
          HttpStatus.BAD_REQUEST
        );
      }
    } catch (error) {
      throw new BadRequestException(error.response);
    }
  }

  async forgotAdminPassword(emaildto: emailDto) {
    try {
      const { email } = emaildto;
      const user = await this.userRepository.findOne({ where: { email } });
      if (!user) {
        throw new HttpException(
          {
            status: HttpStatus.NOT_FOUND,
            message: "Please enter valid mail address!",
          },
          HttpStatus.NOT_FOUND
        );
      }
      let payload: AuthJwtPayload = { email: email, userRole: user.userRole };
      if (user.userRole == "Admin") {
        const token = await this.jwtService.signAsync(payload, {
          secret: process.env.JWT_SECRET,
          expiresIn: "24h",
        });
        const subject = "5W Foundation - Email Verification Request and Reset Your Password";
        const name = "Admin";
        const link = `https://stage-admin.5wf.org/CreatePasswordPage/?token=${token}`;
        const what = " and reset password";
        let newEmailMsg = this.mailing.mailHtmlFormat(name, what, link);

        // Sending email with JWT Token
        await this.sendGridEmailService.sendEmail(email, subject, newEmailMsg);
        return { success: 200, message: "email sent successfully" };
      } else {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            message: "This is only for Admin!",
          },
          HttpStatus.BAD_REQUEST
        );
      }
    } catch (error) {
      throw new BadRequestException(error.response);
    }
  }

  async getAllProductDetails(
    pageNo,
    limit,
    sorting,
    field,
    req
  ): Promise<Species | Projects | any> {
    try {
      let products = [];
      let order;
      if (req.user.userRole == "Admin") {
        if (!pageNo) {
          pageNo = 1;
        }
        if (!sorting || !field) {
          sorting = "desc";
          field = "createdAt";
          order = `order by "${field}" ${sorting}`;
        }

        if (field == "donationAmount") {
          order = ``;
        } else {
          order = `order by "${field}" ${sorting}`;
        }

        const usdAmount = await this.currencyPriceRepo.query(
          `select * from latest_currency_price`
        );
        const _5WFDonation = await this.transactionService.get5WFDonations();
        console.log("::::::5WFDONATION", _5WFDonation);
        await this.usdAmounforAllProductsOr5WF(_5WFDonation, usdAmount);
        const responseProducts =
          await this.speciesRepoTransaction.getAllProducts(order);
        await this.usdAmounforAllProductsOr5WF(responseProducts, usdAmount);
        const data = responseProducts;

        if (!order) {
          if (sorting == "asc" && field == "donationAmount") {
            data.sort((a, b) => a.donationAmount - b.donationAmount);
          }
          if (sorting == "desc" && field == "donationAmount") {
            data.sort((a, b) => b.donationAmount - a.donationAmount);
          }
        }

        if (!limit) {
          data.length < 10 ? (limit = data.length) : (limit = 10);
        }
        const pageSize = Math.ceil(data.length / limit);
        for (
          let i = (pageNo - 1) * limit;
          i < pageNo * limit && i < data.length;
          i++
        ) {
          products.push(data[i]);
        }

        return {
          pageCount: pageSize,
          rowCount: products.length,
          totalCount: data.length,
          data5wf: _5WFDonation,
          data: products,
        };
      } else {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            message: "Admin can access only access this pages!",
          },
          HttpStatus.BAD_REQUEST
        );
      }
    } catch (error) {
      console.log(error);
      throw new BadRequestException(error.response);
    }
  }

  async isActivePorduct(body, req): Promise<Species | Projects | any> {
    try {
      const { id, active } = body;
      if (req.user.userRole == "Admin") {
        const species = await this.speciesRep.findOne({ where: { id } });
        const project = await this.projectRep.findOne({ where: { id } });
        if (species) {
          if (species.id) {
            let dataq = `
                UPDATE public.species SET "isActive" = '${active}' WHERE id= '${id}'`;
            console.log(dataq);
            await this.speciesRep.query(dataq);
            return {
              success: 200,
              message: "Successfully upadte isActive status in Species!",
            };
          }
        }

        if (project) {
          if (project.id) {
            let dataq = `
                UPDATE public.projects SET "isActive" = '${active}' WHERE id= '${id}'`;
            console.log(dataq);
            await this.projectRep.query(dataq);
            return {
              success: 200,
              message: "Successfully upadte isActive status in Project!",
            };
          }
        }
        if (!species || !project) {
          throw new HttpException(
            {
              status: HttpStatus.NOT_FOUND,
              message: "Invaild Details Species or Project!",
            },
            HttpStatus.NOT_FOUND
          );
        }
      } else {
        throw new HttpException(
          {
            status: HttpStatus.BAD_REQUEST,
            message: "Admin can access only access this pages!",
          },
          HttpStatus.BAD_REQUEST
        );
      }
    } catch (error) {
      console.log(error);
      throw new BadRequestException(error.response);
    }
  }

  async usdAmounforAllProductsOr5WF(result, usdAmount) {
    for (let i = 0; i < result.length; i++) {
      let sum = 0;
      // console.log(result[i].donationAmount);
      for (let j of Object.keys(result[i].donationAmount)) {
        // console.log(j);
        result[i].donationAmount[j] /= usdAmount[0][j.toUpperCase()];
        // console.log(result[i]);
        sum += result[i].donationAmount[j];
      }
      result[i].donationAmount = sum;
      // console.log(sum);
    }
  }
}
