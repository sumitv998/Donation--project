import { ApiProperty } from "@nestjs/swagger";
import { IsEnum, IsNotEmpty, IsNumber, IsString } from "class-validator";
import { GENDER } from "../entities/usersCorporate.entity";

export class EditProfileDto {
  @ApiProperty({ example: "Dheeraj" })
  @IsString()
  @IsNotEmpty()
  firstName: string;

  @ApiProperty({ example: "kumar" })
  @IsString()
  @IsNotEmpty()
  lastName: string;

  @ApiProperty({ example: 22 })
  @IsNumber()
  @IsNotEmpty()
  age: number;

  @ApiProperty({ example: GENDER.MALE })
  @IsEnum(GENDER)
  @IsNotEmpty()
  gender: GENDER;

  @ApiProperty({ example: "Mumbai" })
  @IsString()
  @IsNotEmpty()
  city: string;

  @ApiProperty({ example: "India" })
  @IsString()
  @IsNotEmpty()
  country: string;
}
