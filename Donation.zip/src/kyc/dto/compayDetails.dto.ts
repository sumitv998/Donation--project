import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsOptional, IsString } from "class-validator";

export class companyDetailsDto {
  @ApiProperty()
  @IsString()
  companyId: string;

  @ApiProperty()
  @IsString()
  companyAdd: string;

  @ApiProperty()
  @IsOptional()
  companyDoc: string;

  @ApiProperty()
  @IsNotEmpty()
  sigDOB: string;

  @ApiProperty()
  @IsOptional()
  personDoc: string;

  @ApiProperty()
  @IsString()
  locale: string;
}
