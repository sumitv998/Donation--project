import { IsNotEmpty } from "class-validator";

export class createDonation {

  @IsNotEmpty()
  id: string;
  
  @IsNotEmpty()
  type: string;
}
