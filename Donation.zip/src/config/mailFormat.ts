export class mailFormat {
  constructor() {}

  mailHtmlFormat(name, what, link) {
    let mailing = `<!DOCTYPE html>
    <html lang="en">
    
    <head>
        <style>
            body {
                font-size: small;
                /* color: #f5f6f7;
              background-image: url('https://fivewfstaging.s3.ap-south-1.amazonaws.com/hero-section-bg.png'); */
            }
    
            .btn:hover {
                background-color: #276b5b;
                color: white;
            }
    
            .btn:hover a {
                color: white !important;
            }
    
            .btn {
                text-align: center;
            }
    
            .paragraph {
                font-size: small;
            }
    
            .f14 {
                font-size: small;
                font-weight: 300;
                color: black;
            }
        </style>
    </head>
    
    <body>
        <div>
            <a href="https://stage-app.5wf.org/"><img src="https://fivewfstaging.s3.ap-south-1.amazonaws.com/AdminLogo.jpg"
                    alt="5WF Logo" style="height: 50px; width: 50px" /></a>
            <p class="paragraph f14">
                Hello there <span style="font-weight: bold">${name},</span>
            </p>
            <p class="f14">
                Welcome to 5W Foundation and thank you for signing up to help threatened
                species. Please confirm your email ${what}.
            </p>
            <button class="btn">
                <a href="${link}" style="color: black; font-size: 14px; text-decoration: none">Verify mail</a>
            </button>
            <p class="f14">
                If the above link is not clickable, try copying and pasting it into the
                address bar of your web browser
            </p>
            <p class="f14"><i>${link}</i></p>
            <p class="f14">
                If you have any questions, please
                <a style="text-decoration: none" href="mailto:info@5wf.org">contact us</a>, or get in touch on Twitter
                <a style="text-decoration: none" href="https://twitter.com/5WFoundation">@5wfoundation</a>.
            </p>
            <p class="f14" style="margin-top: 20px">
                Best regards<br />
                <b>5W Foundation</b>
            </p>
            <p style="font-size: 9pt; color: grey; margin-top: 25px">
                <i>
                    ©Copyright 2020 Stichting 5W Foundation. All rights reserved. Various
                    trademarks held by their respective owners. Postal: PO Box 78049,
                    1070LP Amsterdam, North Holland, Netherlands | KvK: 85846759 | RSIN:
                    863764939
                </i>
            </p>
        </div>
    </body>
    
    </html>`;
    return mailing;
  }
}
