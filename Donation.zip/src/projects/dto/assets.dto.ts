export class AssestDto {

  coverImage: any;

  // @IsNotEmpty()
  images: any;

  projectVideo: any;

}
