import { ApiProperty } from "@nestjs/swagger";
import { UsersCorporates } from "../../users/entities/usersCorporate.entity";
import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { Projects } from "./project.entity";

@Entity()
export class AssetProjects {
  @PrimaryGeneratedColumn("uuid")
  public id: string;

  @ApiProperty()
  @ManyToOne(()=> Projects, (projects) => projects.assets)
  @JoinColumn({name:'projectId'})
  projects: Projects;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  url: string;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  type: string;

  @ApiProperty()
  @Column()
  projectId:string;
}
