import { BadRequestException, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { paymentEmailReceipt } from "src/services/paymentEmailReceipt.service";
import { SendGridEmailService } from "src/services/sendgridEmail.service";
import Stripe from "stripe";
import { Repository } from "typeorm";
import { StripeInvoice5WFDto, StripeInvoiceDto } from "./dto/stripe.dto";
import { paymentTransactions, STATUS } from "./entities/payments.entity";
import { TransactionService } from "./transaction.repo";

@Injectable()
export class StripeService {
  private stripe;
  constructor(
    @InjectRepository(paymentTransactions)
    private readonly transactionRepo: Repository<paymentTransactions>,
    private readonly transactionService: TransactionService,
    private readonly payReceipt: paymentEmailReceipt,
    private readonly emailService: SendGridEmailService
  ) {
    this.stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
      apiVersion: "2022-11-15",
    });
  }

  async createCheckoutForFiat(req, res, body: StripeInvoiceDto) {
    try {
      const userId = req.user.userId;
      const { price_amount, pay_currency, _5wfAmount, products } = body;
      // create array of products for checkout session's line_items
      const lineItems = [];
      body.products.forEach((product) => {
        lineItems.push({
          price_data: {
            currency: pay_currency,
            product_data: {
              name: product.name,
              metadata: {
                productType: product.productType,
                productId: product.productId,
              },
            },
            unit_amount: product.amount * price_amount,
          },
          quantity: 1,
        });
      });
      if (_5wfAmount) {
        lineItems.push({
          price_data: {
            currency: pay_currency,
            product_data: {
              name: "5WF",
              metadata: {
                productType: "5WF",
                productId: null,
              },
            },
            unit_amount: _5wfAmount * 100,
          },
          quantity: 1,
        });
        products.push({
          name: null,
          productType: "5WF",
          productId: null,
          amount: _5wfAmount,
        });
      }
      const session = await this.stripe.checkout.sessions.create({
        customer_email: req.user.email,
        line_items: lineItems,
        success_url: `${process.env.SUCCESS_URL}?pay_amount=${
          price_amount + _5wfAmount
        }`,
        cancel_url: `${process.env.FAILURE_URL}?pay_amount=${
          price_amount + _5wfAmount
        }`,
        mode: "payment",
      });
      await this.transactionService.createcreateTransactionForFiat(
        body,
        userId,
        session.id
      );
      res.json({ url: session.url });
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async createCheckoutSessionFor5WF(req, res, body: StripeInvoice5WFDto) {
    try {
      const userId = req.user.userId;
      const { pay_currency, _5wfAmount } = body;
      const session = await this.stripe.checkout.sessions.create({
        customer_email: req.user.email,
        line_items: [
          {
            price_data: {
              currency: pay_currency,
              product_data: {
                name: "5WF",
                metadata: {
                  productType: "5WF",
                  productId: null,
                },
              },
              unit_amount: _5wfAmount * 100,
            },
            quantity: 1,
          },
        ],
        success_url: `${process.env.SUCCESS_URL}?pay_amount=${_5wfAmount}`,
        cancel_url: `${process.env.FAILURE_URL}?pay_amount=${_5wfAmount}`,
        mode: "payment",
      });
      await this.transactionService.createcreateTransactionForFiat5WF(
        body,
        userId,
        session.id
      );
      res.json({ url: session.url });
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async callbackNotificationForFiat(payload: Buffer, sig, res) {
    try {
      console.log("Signature::", sig);
      console.log("BODY::", payload);
      let event;
      try {
        event = this.stripe.webhooks.constructEvent(
          payload,
          sig,
          process.env.STRIPE_WEBHOOK_SECRET
        );
        console.log("EVENT::::", event);
      } catch (err) {
        console.log(err.message);
        console.log("EVENT:::", event);
        res.status(400).send(`Webhook Error: ${err.message}`);
      }
      let status;
      switch (event.type) {
        case "checkout.session.async_payment_failed":
          status = STATUS.FAILED;
          // Then define and call a function to handle the event checkout.session.async_payment_failed
          break;
        case "checkout.session.async_payment_succeeded":
          status = STATUS.SUCCESS;
          // Then define and call a function to handle the event checkout.session.async_payment_succeeded
          break;
        case "checkout.session.completed":
          status = STATUS.SUCCESS;
          // Then define and call a function to handle the event checkout.session.completed
          break;
        case "checkout.session.expired":
          status = STATUS.EXPIRED;
          // Then define and call a function to handle the event checkout.session.expired
          break;
        // ... handle other event types
        default:
          status = STATUS.UNEXPECTED;
        // console.log(`Unhandled event type ${req.body.type}`);
      }
      const sessionId = event.data.object.id;
      const totalAmount = event.data.object.amount_total;
      const customerEmail = event.data.object.customer_email;
      let statusImg = "";
      await this.transactionRepo.query(
        `update payment_transactions set status='${status}' where "invoiceId" ='${sessionId}' `
      );
      if (status == "Success") {
        statusImg += `<div class="justifyCenterClass">
        <img src="https://fivewfstaging.s3.ap-south-1.amazonaws.com/success.png" alt="Success" class="statusImg" />
      </div>`;
      }
      if (status == "Failed") {
        statusImg += `<div class="justifyCenterClass">
        <img src="https://fivewfstaging.s3.ap-south-1.amazonaws.com/fail.png" alt="Failed" class="statusImg" />
      </div>`;
      }
      this.sendPaymentReceipt(sessionId, customerEmail, statusImg, totalAmount / 100);
      res.send();
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async sendPaymentReceipt(
    invoiceId: string,
    customerEmail: string,
    statusImg:string,
    totalAmount: number
  ) {
    const items = await this.transactionRepo
      .query(`select pt."invoiceId", pt."is5WF", s.id as "speciesId", p.id as "projectId",
      s."speciesName", p."projectName", pt."paidCurrency", pt."paidAmount"
      from payment_transactions pt left join species s on s.id = pt."speciesId" 
      left join projects p on p.id = pt."projectId" where "invoiceId" = '${invoiceId}'`);
    let itemHtml = "";
    const paidCurrency = items[0].paidCurrency;
    const subject = "5W Foundation Donation Payment Receipt";
    for (let i in items) {
      let item = "";
      if (items[i].is5WF == true) {
        item += "5W Foundation";
      }
      if (items[i].speciesId != null) {
        item += `${items[i].speciesName}`;
      }
      if (items[i].projectId != null) {
        item += `${items[i].projectName}`;
      }

      itemHtml += `<tr>
      <td data-label="Product Name">${item}</td>
      <td align="right" data-label="Amount">${items[
        i
      ].paidCurrency.toUpperCase()} ${items[i].paidAmount}</td>
    </tr>`;
    }
    const emailBody = await this.payReceipt.paymentReceipt(
      invoiceId,
      itemHtml,
      statusImg,
      paidCurrency,
      totalAmount
    );
    await this.emailService.sendEmail(customerEmail, subject, emailBody);
  }
}
