import { ApiProperty } from "@nestjs/swagger";
import {
  IsArray,
  IsBoolean,
  IsEnum,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from "class-validator";

export enum TYPE {
  SPECIES = "Species",
  PROJECT = "Project",
  FIVEWF = "5WF",
}
export class nowPaymentsInvoiceDto {
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  price_amount: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  price_currency: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  payCurrency: string;

  @ApiProperty()
  @IsOptional()
  @IsNumber()
  _5wfAmount!: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsArray()
  orderDescription: Product[];
}

export class nowPaymentsInvoice5WFDto{
  @ApiProperty()
  @IsNotEmpty()
  @IsNumber()
  price_amount: number;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  price_currency: string;

  @ApiProperty()
  @IsNotEmpty()
  @IsString()
  payCurrency: string;
}

export class Product {
  productType: string;
  productId: string;
  amount: number;
}
