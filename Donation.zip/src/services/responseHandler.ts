import { Injectable } from "@nestjs/common";

@Injectable()
export class responseValidation {
  validateResponse(value, error, message) {
    if (error == null) {
      return { status: 200, Response: value, message: message };
    } else {
      return { status: error.code, message: message ? message : error.message };
    }
  }
}
