import { InjectRepository } from "@nestjs/typeorm";
import { Entity, Repository } from "typeorm";
import { Species } from "./entities/species.entity";

@Entity()
export class SpeciesRepository {
  constructor(
    @InjectRepository(Species)
    private speciesRep: Repository<Species>
  ) {}

//   async getAllProducts(order) {
//     const response = await this.speciesRep.query(`        
//             select s.id, s."speciesName" as "productName", 'Species' as "productType", 
//             s."speciesNameScientific" as "speciesName", s."createdAt" as "createdAt", s."isActive", as2.url 
//             from species s left join asset_species as2 on s.id = as2."speciesId" 
//             and as2."type" = 'speciesProfile' group by s.id, as2.url
//             union all 
//             select p.id, p."projectName" as "productName", 'Project' as "productType",
//             s2."speciesName" as "speciesName", p."createdAt" as "createdAt", p."isActive", ap.url  
//             from projects p left join species s2 on s2.id = p."speciesId" left join asset_projects ap 
//             on ap."projectId" = p.id and ap."type" = 'projectProfile' group by p.id, ap.url, s2."speciesName"
//             ${order}`);
//     return response;
//   }
  async getAllProducts(order) {
    const response = await this.speciesRep.query(`        
            (with tmp as (select s.id, pt.currency, sum(pt.amount) 
            as "totalAmount" from species s
            left join payment_transactions pt on s.id = pt."speciesId"
            where pt."speciesId" = s.id 
            and pt.status = 'Success' group by pt.currency, s.id)
            select * from (select s3.id, s3."speciesName" as "productName", s3."speciesNameScientific" as "speciesName", s3."isActive", as2.url,
            jsonb_object_agg(coalesce(tmp.currency, 'usd'), coalesce(tmp."totalAmount",0)) as "donationAmount", s3."createdAt",
            row_number() over (partition by s3.id) as rowNumber from species s3 
            left join tmp on s3.id = tmp.id  
            left join asset_species as2 on as2."speciesId" = s3.id and as2."type" = 'coverImage'
            group by s3.id, as2.url) as tempTable where tempTable.rowNumber = 1)     
            union all
            (with tmp1 as (select p.id, pt2.currency, sum(pt2.amount) as "totalAmount" from projects p 
            left join payment_transactions pt2 on p.id = pt2."projectId"
            left join species s2 on s2.id = p."speciesId" 
            where pt2."projectId" = p.id 
            and pt2.status = 'Success' group by pt2.currency, p.id)
            select * from (select p2.id, p2."projectName" as "productName", s4."speciesName", p2."isActive", ap.url,
            jsonb_object_agg(coalesce(tmp1.currency, 'usd'), coalesce(tmp1."totalAmount",0)) as "donationAmount", p2."createdAt",
            row_number() over (partition by p2.id) as rowNumber from projects p2 left join species s4 on s4.id = p2."speciesId"
            left join tmp1 on p2.id = tmp1.id
            left join asset_projects ap on ap."projectId" = p2.id and ap."type" = 'coverImage'
            group by p2.id, s4."speciesName", ap.url) as tempTable where tempTable.rowNumber = 1)
            ${order}`);
    return response;
  }
}
