export enum PROJECTNAME {
  ALL = "All",
  A_TO_E = "A-E",
  F_TO_J = "F-J",
  K_TO_O = "K-O",
  P_TO_T = "P-T",
  U_TO_Z = "U-Z",
}
