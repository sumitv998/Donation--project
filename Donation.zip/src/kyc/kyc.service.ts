import { HttpService } from "@nestjs/axios";
import {
  BadRequestException,
  ForbiddenException,
  HttpException,
  HttpStatus,
  Injectable,
} from "@nestjs/common";
import { catchError, firstValueFrom, map } from "rxjs";
import { companyDetailsDto } from "./dto/compayDetails.dto";
import * as FormData from "form-data";
import { InjectRepository } from "@nestjs/typeorm";
import { kycDetails } from "./entities/companyInfo.entity";
import { Repository } from "typeorm";
import { KycLivenessDto } from "./dto/kycLiveness.dto";
import { UsersCorporates } from "src/users/entities/usersCorporate.entity";
import { S3Service } from "src/services/s3.service";
import { SendGridEmailService } from "src/services/sendgridEmail.service";

@Injectable()
export class KycService {
  constructor(
    private readonly httpService: HttpService,
    @InjectRepository(kycDetails)
    private readonly kycDetailsRepo: Repository<kycDetails>,
    @InjectRepository(UsersCorporates)
    private readonly userCorporateRepo: Repository<UsersCorporates>,
    private readonly s3BucketService: S3Service,
    private readonly sendgridEmailService: SendGridEmailService
  ) {}

  async forgeryCheckForCorporate(
    companyDoc,
    personDoc,
    req,
    body: companyDetailsDto
  ) {
    try {
      // create data for user in KYC details
      const email = req.user.email;
      const userObj = await this.userCorporateRepo.findOneBy({ email: email });
      if (!userObj) {
        throw new BadRequestException("User does not exist");
      }
      const isExist = await this.kycDetailsRepo.query(
        `select kd."userId", kd."isLivenessCheckVerified" from kyc_details kd where "userId" = '${userObj.id}'`
      );
      console.log("isExist", isExist);
      if (isExist[0]) {
        if (
          [
            "Pending",
            "Declined",
            "FAILED",
            "CANCELLED",
            "ANALYSING",
            "NOT STARTED",
            "NOT REQUESTED",
          ].includes(isExist[0].isLivenessCheckVerified)
        )
          return {
            liveness: false,
            message:
              "Corporate forgery check already verified, please go for liveness check",
          };
      }
      console.log(companyDoc);
      let s3CompanyDoc = await this.s3BucketService.uploadFile(companyDoc[0]);
      let s3PersonDoc = await this.s3BucketService.uploadFile(personDoc[0]);

      console.log(companyDoc);
      const arr = [];
      const company = "Company";
      const person = "Person";
      const companyForge = this.getForgeryDataForCorporate(companyDoc, company);
      arr.push(companyForge);
      const personForge = this.getForgeryDataForCorporate(personDoc, person);
      arr.push(personForge);
      await Promise.all(arr);

      const companyForgeId: any = await this.getIdFromPromise(companyForge);
      const personForgeId: any = await this.getIdFromPromise(personForge);
      console.log("companyId", companyForgeId);
      console.log("personId", personForgeId);

      const getStatus = await this.getForgeryResult(
        companyForgeId,
        personForgeId
      );

      if (getStatus == true) {
        const kycData = new kycDetails();
        kycData.user = userObj;
        kycData.companyDoc = s3CompanyDoc.Location;
        kycData.personDoc = s3PersonDoc.Location;
        kycData.sigDOB = body.sigDOB;
        kycData.companyId = body.companyId;
        kycData.companyAddress = body.companyAdd;
        kycData.companyForgeryId = companyForgeId;
        kycData.forgeryForCompany = true;
        kycData.personForgeryId = personForgeId;
        kycData.forgeryForPerson = true;
        await this.kycDetailsRepo.save(kycData);
        return {
          success: true,
          message: "forgery check for both company and person has approved",
        };
      }
      return {
        success: false,
        message: "forgery check for company or person has rejected",
      };
    } catch (error) {
      console.log(error.message);
      throw new BadRequestException({ status: false, message: error.message });
    }
  }

  async getIdFromPromise(data: any) {
    const res = await data.then((res) => {
      console.log("ID:::", res.id);
      return res.id;
    });
    console.log(";;;;;;", res);
    return res;
  }

  async getForgeryResult(companyForgeId: string, personForgeId: string) {
    const res1 = await this.pollingResult(companyForgeId);
    const res2 = await this.pollingResult(personForgeId);
    if (
      res1.score === "Normal" ||
      (res1.riskScore < 50 && res2.score === "Normal") ||
      res2.riskScore < 50
    ) {
      return true;
    }
    return false;
  }

  async pollingResult(id) {
    let state;
    let status = false;
    while (status == false) {
      state = await this.getForgeryStatus(id);
      if (state.score) status = true;
    }
    return state;
  }

  async getForgeryDataForCorporate(file, whose) {
    try {
      let status = false;
      let response;
      let i = 0;
      while (status == false) {
        if (i == 4) {
          throw new BadRequestException(
            "Something went wrong with forgery check, please try after sometime"
          );
        }
        response = await this.forgeryCheck(file, whose);
        console.log(response);
        if (response.status == true) {
          status = true;
        }
        i += 1;
      }
      return response.data;
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async forgeryCheck(file, whose) {
    const doc = file[0];
    console.log("DOC:::", doc);
    const formData = new FormData();
    formData.append("document", doc.buffer, { filename: doc.originalname });
    formData.append(
      "webhook",
      // `https://5995-103-175-191-233.in.ngrok.io/kyc/webhookForForgeryCheck?whose=${whose}`
      `https://stage-api.5wf.org/kyc/webhookForForgeryCheck?whose=${whose}`
    );
    let status = false;
    console.log("One Time");
    const response = await firstValueFrom(
      this.httpService
        .post(
          "https://test-gateway.zignsec.com/api/v4/scanning/forgery",
          formData,
          {
            headers: {
              Authorization: process.env.KYC_ACCESS_KEY,
              "Content-Type": "multipart/form-data",
            },
          }
        )
        .pipe(
          map(async (res) => {
            console.log("Data:::::::::", res.data);
            status = true;
            return res.data;
          })
        )
        .pipe(
          catchError((e: any) => {
            return "false";
          })
        )
    );
    return { data: response, status: status };
  }

  async forgeryCheckForPerson(file, whose): Promise<any> {
    console.log("FILE::::", file);
    const formData = new FormData();
    formData.append("document", file.buffer, { filename: file.originalname });
    formData.append(
      "webhook",
      // `https://5995-103-175-191-233.in.ngrok.io/kyc/webhookForForgeryCheck?whose=${whose}`
      `https://stage-api.5wf.org/kyc/webhookForForgeryCheck?whose=${whose}`
    );
    let status = false;
    console.log("Two Time");
    const response = await firstValueFrom(
      this.httpService
        .post(
          "https://test-gateway.zignsec.com/api/v4/scanning/forgery",
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
              Authorization: process.env.KYC_ACCESS_KEY,
            },
          }
        )
        .pipe(
          map((res) => {
            status = true;
            return res.data;
          })
        )
        .pipe(
          catchError((e) => {
            console.log(e.message);
            return "false";
          })
        )
    );
    return { data: response, status: status };
  }

  async webhookForForgeryCheck(whose: string, body: any) {
    try {
      console.log("::::::::whose", whose, "::::");
      console.log(":::::::::::::::::::::::::::::", body, "::::::::::");
      if (whose === "Company") {
        if (body.score === "Normal" || body.riskScore < 50) {
          // Update forgeryOfCompany is true
        } else {
          //  delete data
        }
      }
      if (whose === "Person") {
        if (body.score === "Normal" || body.riskScore < 50) {
          // Update forgeryOfPerson is true
        } else {
          // delete data
        }
      }
      return "Success";
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  // Person liveness checking

  async livenessCheckForPerson(locale, req): Promise<any> {
    try {
      const user = await this.userCorporateRepo.findOne({
        where: { email: req.user.email },
      });
      console.log("USER", user);
      const response = await firstValueFrom(
        this.httpService
          .post(
            "https://test-gateway.zignsec.com/core/api/sessions/identity_verification/liveness",
            {
              locale: locale,
              metadata: {
                locale: locale,
                options: "FrontSide",
              },
              redirect_failure: process.env.KYC_FAILURE_URL,
              redirect_success: process.env.KYC_SUCCESS_URL,
              relay_state: "string",
              // webhook: `https://5995-103-175-191-233.in.ngrok.io/kyc/webhookForLivenessCheck?userId=${user.id}`,
              webhook: `https://stage-api.5wf.org/kyc/webhookForLivenessCheck?userId=${user.id}`,
            },
            {
              headers: {
                "Content-Type": "application/json",
                Authorization: process.env.KYC_SUBSCRIPTION_KEY,
              },
            }
          )
          .pipe(
            map((resp) => {
              return resp.data;
            })
          )
          .pipe(
            catchError((e) => {
              console.log("ERROR::::::", e.message, e.response.data);
              throw new ForbiddenException(
                "KYC liveness check failed, please try again"
              );
            })
          )
      );
      const message = `<a href= "${response.data.redirect_url}"> Liveness test </a>`;
      await this.sendgridEmailService.sendEmail(
        user.email,
        "5WF - Liveness Test",
        message
      );
      return response;
    } catch (error) {
      console.log(error);
      throw new BadRequestException(
        "Something went wrong with liveness check, please try again"
      );
    }
  }

  async webhookForLivenessCheck(body: any, userId: string) {
    try {
      console.log("Liveness Result::::", body);
      if (
        body.result.total_result == "Declined" ||
        body.result.total_result == "FAILED" ||
        body.result.total_result == "CANCELLED" ||
        body.result.total_result == "ANALYSING" ||
        body.result.total_result == "NOT STARTED" ||
        body.result.total_result == "NOT REQUESTED"
      ) {
        await this.kycDetailsRepo
          .query(`update kyc_details set "isLivenessCheckVerified"='${body.result.total_result}'::character varying 
          where "userId" = '${userId}'`);
        throw new BadRequestException(
          "KYC lieness check failed, please try again"
        );
      }
      if (body.result.total_result == "ACCEPTED") {
        // update data as kycLiveness true in KYC details table
        await this.kycDetailsRepo
          .query(`update kyc_details set "isLivenessCheckVerified"='Success'::character varying 
          where "userId" = '${userId}'`);
        await this.pepAndSanctionCheckForCorporate(userId);
        return {
          status: true,
          message: "Liveness test is verified",
        };
      }
    } catch (error) {
      throw new BadRequestException(error.response);
    }
  }

  async pepAndSanctionCheckForCorporate(userId: string) {
    try {
      console.log("Pending:::::::::::", userId);
      const isExist = await this.userCorporateRepo
        .query(`select uc.country, uc."companyName", uc."representativeName", kd."sigDOB"
          from users_corporates uc 
          left join kyc_details kd on uc.id = kd."userId" where uc.id = '${userId}'`);
      console.log(":::::::::::::::::", isExist);
      const data = await this.getDataOfPepSanction(isExist[0]);
      console.log("Data:::::", data);
      await this.getResultForPepSanction(data.company, data.person, userId);
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async getDataOfPepSanction(data: any) {
    const { country, companyName, representativeName, sigDOB } = data;
    let statusOfCompany = false;
    let statusOfPerson = false;
    let res1;
    let res2;
    console.log("On going::::::::::::");
    while (statusOfCompany == false) {
      res1 = await this.pepAndSanctionForCompany(country, companyName);
      if (res1.status == true) statusOfCompany = true;
    }
    while (statusOfPerson == false) {
      res2 = await this.pepAndSanctionForPerson(
        country,
        representativeName,
        sigDOB
      );
      if (res2.status == true) statusOfPerson = true;
    }
    return { company: res1.data, person: res2.data };
  }

  async getResultForPepSanction(
    companySanctionData: any,
    personSanctionData: any,
    userId: string
  ) {
    const data = personSanctionData.data.result.matches;
    let personStatus = false;
    console.log("MatchesPerson", data.length);
    for (let i in data) {
      if (data[i].entity.dateOfBirth && data[i].matchedFields.length > 1) {
        personStatus = true;
        break;
      }
    }
    console.log("Object::::::Object::::::", personStatus);
    if (
      companySanctionData.data.result.numberOfMatches === 0 &&
      personStatus === false
    ) {
      await this.userCorporateRepo.query(
        `update users_corporates set "updateAt"=now(), "isVerified" = true where id='${userId}'`
      );
      return true;
    } else {
      const buf1 = Buffer.from(JSON.stringify(companySanctionData));
      const buf2 = Buffer.from(JSON.stringify(personSanctionData));
      console.log("Buffer1", buf1);
      console.log("Buffer2", buf2);
      const arr = [];
      let company = "companyPepSanction";
      let person = "personPepSanction";
      const companyData = this.s3BucketService.uploadJsonFile(buf1, company);
      const personData = this.s3BucketService.uploadJsonFile(buf2, person);
      arr.push(companyData);
      arr.push(personData);
      await Promise.all(arr);
      const pathOfCompanyData = await this.getLinkForJsonFile(companyData);
      const pathOfPersonData = await this.getLinkForJsonFile(personData);
      await this.kycDetailsRepo
        .query(`update kyc_details set "pepSanctionForCompany"='${pathOfCompanyData}',
          "pepSanctionForPerson"='${pathOfPersonData}' where "userId" = '${userId}'`);
      return false;
    }
  }

  async getLinkForJsonFile(data: any) {
    const res = await data.then((res) => {
      console.log("DOCLink::::", res);
      return res.Location;
    });
    return res;
  }

  async pepAndSanctionForCompany(country: string, companyName: string) {
    let status = false;
    console.log("Company:::::::::::::::");
    const res = await firstValueFrom(
      this.httpService
        .post(
          "https://test-gateway.zignsec.com/core/api/sessions/company_check/watchlist",
          {
            metadata: {
              country: country,
              name: companyName,
              scan_settings: {
                exact: false,
                max_result_count: 100,
              },
            },
            relay_state: "string",
            webhook: "string",
          },
          {
            headers: {
              Authorization: process.env.KYC_SUBSCRIPTION_KEY,
            },
          }
        )
        .pipe(
          map(async (res) => {
            status = true;
            return res.data;
          })
        )
        .pipe(
          catchError((e) => {
            return "false";
          })
        )
    );
    console.log("resCompany:::", res, status);
    return { data: res, status: status };
  }

  async pepAndSanctionForPerson(
    country: string,
    representativeName: string,
    sigDOB: string
  ) {
    let status = false;
    console.log("Name:::::::::", representativeName);
    console.log("Country:::::::::", country);
    console.log("DOB:::::::::", sigDOB);
    const name = representativeName.split(" ");
    let name1 = [];
    let first = "";
    let last = "";
    for (let i in name) {
      if (name[i].length > 2) {
        name1.push(name[i]);
      }
    }
    if (name1.length > 1) {
      first += name1[0];
      last += name1[name1.length - 1];
    } else {
      first += name1[0];
    }
    const res = await firstValueFrom(
      this.httpService
        .post(
          "https://test-gateway.zignsec.com/core/api/sessions/identity_check/watchlist",
          {
            metadata: {
              country: country,
              date_of_birth: sigDOB,
              first_name: first,
              last_name: last,
              middle_name: "",
              original_name: `${representativeName}`,
              scan_settings: {
                match_rate: 50,
                max_result_count: 100,
              },
            },
            relay_state: "string",
            webhook: "string",
          },
          {
            headers: {
              Authorization: process.env.KYC_SUBSCRIPTION_KEY,
              "Content-Type": "application/json",
            },
          }
        )
        .pipe(
          map(async (res) => {
            status = true;
            return res.data;
          })
        )
        .pipe(
          catchError((e) => {
            return "false";
          })
        )
    );
    console.log("resPerson", res, status);
    return { data: res, status: status };
  }

  async getForgeryStatus(sessionId: string) {
    const response = await firstValueFrom(
      this.httpService
        .get(
          `https://test-gateway.zignsec.com/api/v4/scanning/forgery/${sessionId}`,
          {
            headers: {
              Authorization: process.env.KYC_ACCESS_KEY,
              "Content-Type": "application/json",
            },
          }
        )
        .pipe(
          map(async (res) => {
            return res.data;
          })
        )
        .pipe(
          catchError((e) => {
            console.log(e);
            throw new ForbiddenException("API not available");
          })
        )
    );
    return response;
  }

  async isKYCCompleted(req) {
    try {
      const email = req.user.email;
      console.log("::::::::EMAILData", email);
      const res = await this.kycDetailsRepo
        .query(`select kd."isLivenessCheckVerified", kd."pepSanctionForCompany", 
        kd."pepSanctionForPerson", uc."isVerified" 
        from kyc_details kd left join users_corporates uc on kd."userId" = uc.id 
        where uc.email = '${email}'`);
      console.log("RES:::::", res);
      if (!res[0]) {
        throw new BadRequestException(
          "you have not gone for KYC process, please do that first"
        );
      }
      const {
        isLivenessCheckVerified,
        pepSanctionForCompany,
        pepSanctionForPerson,
        isVerified,
      } = res[0];
      if (isLivenessCheckVerified === "Success") {
        if (isVerified === true) {
          return {
            KYC: true,
            livenessCheck: true,
            message: "KYC process is completed successfully",
          };
        } else if (
          pepSanctionForCompany != null ||
          pepSanctionForPerson != null
        ) {
          return {
            KYC: false,
            livenessCheck: true,
            message:
              "You or Your Company involved in PEP/SANCTION, please wait for approval",
          };
        } else {
          throw new BadRequestException(
            "Something went wrong with KYC, please contact to 5WF Organization"
          );
        }
      } else {
        return {
          livenessCheck: false,
          KYC: false,
          message: "KYC liveness check failed, please try again",
        };
      }
    } catch (error) {
      throw new BadRequestException({ status: false, message: error.message });
    }
  }
}
