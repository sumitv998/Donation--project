import { Module } from "@nestjs/common";
import { AppController } from "./app.controller";
import { AppService } from "./app.service";
import { AdminModule } from "./admin/admin.module";
import { UsersModule } from "./users/users.module";
import { SpeciesModule } from "./species/species.module";
import { ProjectsModule } from "./projects/projects.module";
import { ConfigModule } from "@nestjs/config";
import { TypeOrmModule } from "@nestjs/typeorm";
import { TypeOrmConfigService } from "./config/config.service";
import { APP_INTERCEPTOR } from "@nestjs/core";
import { PostStatusInterceptor } from "./interceptor/postStatus.interceptor";
import { FavouriteModule } from "./favourite/favourite.module";
import { MulterModule } from "@nestjs/platform-express";
import { PaymentsModule } from "./payments/payments.module";
import { KycModule } from "./kyc/kyc.module";
@Module({
  imports: [
    MulterModule.register(),
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: ".env",
    }),
    TypeOrmModule.forRootAsync({ useClass: TypeOrmConfigService }),
    AdminModule,
    UsersModule,
    SpeciesModule,
    ProjectsModule,
    FavouriteModule,
    PaymentsModule,
    KycModule,
  ],
  controllers: [AppController],
  providers: [
    AppService,
    {
      provide: APP_INTERCEPTOR,
      useClass: PostStatusInterceptor,
    },
  ],
})
export class AppModule {}
