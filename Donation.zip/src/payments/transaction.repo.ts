import { BadRequestException, Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository } from "typeorm";
import {
  nowPaymentsInvoice5WFDto,
  nowPaymentsInvoiceDto,
  TYPE,
} from "./dto/nowPayments.dto";
import { StripeInvoice5WFDto, StripeInvoiceDto } from "./dto/stripe.dto";
import { paymentTransactions, STATUS } from "./entities/payments.entity";

@Injectable()
export class TransactionService {
  constructor(
    @InjectRepository(paymentTransactions)
    private readonly transactionRepo: Repository<paymentTransactions>
  ) {}

  async createTransactionForCrypto(
    body: nowPaymentsInvoiceDto,
    id: string,
    description,
    userId: string,
    totalAmount: number
  ) {
    try {
      const { price_amount, price_currency, payCurrency, _5wfAmount } = body;
      const products = JSON.parse(description);
      for (let i = 0; i < products.length; i++) {
        const productId = products[i].productId;
        const amount = (products[i].amount / 100) * price_amount;
        if (products[i].productType == TYPE.SPECIES) {
          await this.transactionRepo.query(
            `INSERT INTO payment_transactions
          (id, "userId", "invoiceId", "is5WF", currency, status, "speciesId",
          "projectId", "paidCurrency", "createdAt", "updatedAt", "paidAmount", amount)
          VALUES(uuid_generate_v4(), '${userId}', '${id}', 
          false, '${price_currency}', '${STATUS.PENDING}', '${productId}', 
          null, '${payCurrency}', now(), now(), ${
              amount / totalAmount
            }, ${amount}::double precision);`
          );
        } else if (products[i].productType == TYPE.PROJECT) {
          await this.transactionRepo.query(
            `INSERT INTO payment_transactions
          (id, "userId", "invoiceId", "is5WF", currency, status, "speciesId",
          "projectId", "paidCurrency", "createdAt", "updatedAt", "paidAmount", amount)
          VALUES(uuid_generate_v4(), '${userId}', '${id}', 
          false, '${price_currency}', '${STATUS.PENDING}', null, 
          '${productId}', '${payCurrency}', now(), now(), ${
              amount / totalAmount
            }, ${amount}::double precision);`
          );
        } else if (products[i].productType == TYPE.FIVEWF) {
          await this.transactionRepo.query(
            `INSERT INTO payment_transactions
          (id, "userId", "invoiceId", "is5WF", currency, status, "speciesId",
          "projectId", "paidCurrency", "createdAt", "updatedAt", "paidAmount", amount)
          VALUES(uuid_generate_v4(), '${userId}', '${id}', 
          true, '${price_currency}', '${STATUS.PENDING}', null, 
          null, '${payCurrency}', now(), now(), ${
              amount / totalAmount
            }, ${_5wfAmount}::double precision);`
          );
        }
      }
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async createTransactionForCrypto5WF(
    body: nowPaymentsInvoice5WFDto,
    response,
    userId
  ) {
    try {
      const { price_currency, price_amount } = body;
      const { id, pay_currency } = response;
      await this.transactionRepo.query(
        `INSERT INTO payment_transactions
    (id, "userId", "invoiceId", "is5WF", currency, status, "speciesId",
    "projectId", "paidCurrency", "createdAt", "updatedAt", "paidAmount", amount)
    VALUES(uuid_generate_v4(), '${userId}', '${id}', 
    true, '${price_currency}', '${STATUS.PENDING}', null, 
    null, '${pay_currency}', now(), now(), 1, ${price_amount}::double precision);`
      );
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async createcreateTransactionForFiat(body: StripeInvoiceDto, userId, Id) {
    try {
      const { price_amount, pay_currency, _5wfAmount, products } = body;
      const arr = [];
      for (let i = 0; i < products.length; i++) {
        const productId = products[i].productId;
        const amount = (products[i].amount / 100) * price_amount;
        if (products[i].productType == TYPE.SPECIES) {
          await this.transactionRepo.query(`INSERT INTO payment_transactions
          (id, "userId", "invoiceId", "is5WF", currency, status, "speciesId",
          "projectId", "paidCurrency", "createdAt", "updatedAt", "paidAmount", amount)
          VALUES(uuid_generate_v4(), '${userId}', '${Id}', 
          false, '${pay_currency}', '${STATUS.PENDING}', '${productId}', 
          null, '${pay_currency}', now(), now(), ${amount}, ${amount}::double precision);`);
        } else if (products[i].productType == TYPE.PROJECT) {
          await this.transactionRepo.query(`INSERT INTO payment_transactions
          (id, "userId", "invoiceId", "is5WF", currency, status, "speciesId",
          "projectId", "paidCurrency", "createdAt", "updatedAt", "paidAmount", amount)
          VALUES(uuid_generate_v4(), '${userId}', '${Id}', 
          false, '${pay_currency}', '${STATUS.PENDING}', null, 
          '${productId}', '${pay_currency}', now(), now(), ${amount}, ${amount}::double precision);`);
        } else if (products[i].productType == TYPE.FIVEWF) {
          await this.transactionRepo.query(`INSERT INTO payment_transactions
          (id, "userId", "invoiceId", "is5WF", currency, status, "speciesId",
          "projectId", "paidCurrency", "createdAt", "updatedAt", "paidAmount", amount)
          VALUES(uuid_generate_v4(), '${userId}', '${Id}', 
          true, '${pay_currency}', '${STATUS.PENDING}', null, 
          null, '${pay_currency}', now(), now(), ${_5wfAmount}, ${_5wfAmount}::double precision);`);
        }
      }
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async createcreateTransactionForFiat5WF(
    body: StripeInvoice5WFDto,
    userId,
    Id
  ) {
    try {
      const { pay_currency, _5wfAmount } = body;
      await this.transactionRepo.query(`INSERT INTO payment_transactions
      (id, "userId", "invoiceId", "is5WF", currency, status, "speciesId",
      "projectId", "paidCurrency", "createdAt", "updatedAt", "paidAmount", amount)
      VALUES(uuid_generate_v4(), '${userId}', '${Id}', 
      true, '${pay_currency}', '${STATUS.PENDING}', null, 
      null, '${pay_currency}', now(), now(), ${_5wfAmount}, ${_5wfAmount}::double precision);`);
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async get5WFDonations() {
    try {
      const response = await this.transactionRepo
        .query(`with tmp as (select pt."paidCurrency", max(pt."createdAt") as "createdAt", 
        sum(pt."paidAmount") from payment_transactions pt 
        where pt."is5WF" = true and pt.status = 'Success' group by pt."paidCurrency")
        select '5WF' as name, max(tmp."createdAt") as "createdAt",
        jsonb_object_agg(tmp."paidCurrency", tmp.sum) as "donationAmount" from tmp group by name
      `);
      return response;
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async getDonationForSpecies(product, rates) {
    try {
      const donation = await this.transactionRepo
        .query(`select pt."paidCurrency", sum(pt."paidAmount") as "totalAmount"
              from payment_transactions pt where pt."speciesId" = '${product.id}' and pt."status" = 'Success' group by pt."paidCurrency" `);
      product["donationAmount"] = await this.getUsdAmount(donation, rates);
      console.log(";;;;;;;", donation);
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async getDonationForProjects(product, rates) {
    try {
      const donation = await this.transactionRepo
        .query(`select pt."paidCurrency", sum(pt."paidAmount") as "totalAmount" 
              from payment_transactions pt where pt."projectId" = '${product.id}' and pt."status" = 'Success' group by pt."paidCurrency"`);
      product["donationAmount"] = await this.getUsdAmount(donation, rates);
      console.log(":::::::::", donation);
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }

  async getUsdAmount(donation, rates) {
    try {
      const mp = {};
      let sum = 0;
      for (let i = 0; i < donation.length; i++) {
        mp[`${donation[i].paidCurrency}`] = donation[i].totalAmount;
      }
      for (let j of Object.keys(mp)) {
        console.log(j);
        sum += mp[j] / rates[0][j.toUpperCase()];
        console.log(mp[j]);
        console.log(rates[0][j.toUpperCase()]);
      }
      console.log(sum);
      return sum;
    } catch (error) {
      throw new BadRequestException(error.message);
    }
  }
}
