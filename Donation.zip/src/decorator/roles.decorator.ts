import { SetMetadata } from "@nestjs/common";
import { ROLE } from "src/users/entities/usersCorporate.entity";

export const Roles = (...roles: ROLE[]) => SetMetadata("roles", roles);