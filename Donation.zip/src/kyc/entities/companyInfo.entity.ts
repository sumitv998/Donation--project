import { ApiProperty } from "@nestjs/swagger";
import { UsersCorporates } from "src/users/entities/usersCorporate.entity";
import {
  Column,
  Entity,
  JoinColumn,
  OneToOne,
  PrimaryGeneratedColumn,
} from "typeorm";

@Entity()
export class kycDetails {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @ApiProperty()
  @OneToOne(() => UsersCorporates)
  @JoinColumn()
  user: UsersCorporates;

  @ApiProperty()
  @Column({ nullable: true })
  companyId: string;

  @ApiProperty()
  @Column({ nullable: true })
  companyAddress: string;

  @ApiProperty()
  @Column({ default: false, nullable: true })
  forgeryForCompany: boolean;

  @ApiProperty()
  @Column({ default: false, nullable: true })
  forgeryForPerson: boolean;

  @ApiProperty()
  @Column({ default: "Pending", nullable: true })
  isLivenessCheckVerified: string;

  @ApiProperty()
  @Column({ nullable: true })
  pepSanctionForCompany: string;

  @ApiProperty()
  @Column({ nullable: true })
  pepSanctionForPerson: string;

  @ApiProperty()
  @Column({ nullable: true })
  companyDoc: string;

  @ApiProperty()
  @Column({ nullable: true })
  sigDOB: string;

  @ApiProperty()
  @Column({ nullable: true })
  personDoc: string;

  @ApiProperty()
  @Column({ nullable: true })
  companyForgeryId: string;

  @ApiProperty()
  @Column({ nullable: true })
  personForgeryId: string;
}
