import { ApiProperty } from "@nestjs/swagger";
import { UsersCorporates } from "../../users/entities/usersCorporate.entity";
import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { Species } from "./species.entity";

@Entity()
export class AssetSpecies {
  @PrimaryGeneratedColumn("uuid")
  public id: string;

  @ApiProperty()
  @ManyToOne(()=> Species, (species) => species.assets)
  @JoinColumn({name:'speciesId'})
  species: Species;

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  url: [];

  @ApiProperty()
  @Column({ type: "varchar", nullable: true })
  type: string;

}
