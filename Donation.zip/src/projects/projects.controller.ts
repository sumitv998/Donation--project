import {
  Controller,
  HttpStatus,
  Post,
  UploadedFiles,
  UseInterceptors,
  Body,
  UseGuards,
  Req,
  HttpException,
} from "@nestjs/common";
import {
  FileFieldsInterceptor,
} from "@nestjs/platform-express";
import { ProjectsService } from "./projects.service";
import { CreateProjectDto } from "./dto/createProject.dto";
import { imageValidation } from "src/services/filesValidation";
import { S3Service } from "src/services/s3.service";
import { JwtAuthGuard } from "src/guards/jwt.guard";

@Controller("projects")
export class ProjectsController {
  constructor(
    private readonly projectsService: ProjectsService,
    private readonly s3Service: S3Service
  ) { }

  @UseGuards(JwtAuthGuard)
  @Post("/createProject")
  @UseInterceptors(
    FileFieldsInterceptor(
      [
        { name: "coverImage", maxCount: 1 },
        { name: "projectVideo", maxCount: 1 },
        { name: "projectProfile", maxCount: 1 },
        { name: "images", maxCount: 8 },
      ],
      imageValidation
    )
  )
  async createSpeciesController(
    @UploadedFiles(
      // new ParseFilePipeBuilder().build({
      //   errorHttpStatusCode: HttpStatus.UNPROCESSABLE_ENTITY,
      // })
    )
    files: {
      coverImage?: Express.Multer.File[];
      projectProfile?: Express.Multer.File[];
      images?: Express.Multer.File[];
      projectVideo?: Express.Multer.File[];
    },
    @Body() body: CreateProjectDto,
    @Req() req
  ) {
    console.log(req.files.images);
    
    if (req.files.images) {
      if (req.files.images.length > 8) {
        throw new HttpException(
          "Only 8 images upload!",
          HttpStatus.BAD_REQUEST
        )
      }
    }

    return this.projectsService.createProject(
      {
        ...body,
        coverImage: req.files.coverImage,
        projectVideo: req.files.projectVideo,
        images: req.files.images,
        projectProfile: req.files.projectProfile,
      },
      req
    );
  }

  // @Patch("/projectProfile")
  // @UseInterceptors(FileInterceptor("projectProfile", imageValidation))
  // uploadProfileImage(
  //   @UploadedFile(
  //     new ParseFilePipeBuilder()
  //       .addMaxSizeValidator({ maxSize: 100000 })
  //       .build({ errorHttpStatusCode: HttpStatus.UNPROCESSABLE_ENTITY })
  //   )
  //   file: Express.Multer.File,
  //   @Query("id") id: string,
  //   @Request() req
  // ) {
  //   return this.projectsService.uploadSpeciesProfile(file, id, req);
  // }
}
