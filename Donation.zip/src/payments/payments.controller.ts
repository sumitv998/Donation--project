import {
  Body,
  Controller,
  HttpCode,
  Post,
  Headers,
  Req,
  Res,
  UseGuards,
} from "@nestjs/common";
import { JwtAuthGuard } from "src/guards/jwt.guard";
import { StripeInvoice5WFDto, StripeInvoiceDto } from "./dto/stripe.dto";
import {
  nowPaymentsInvoice5WFDto,
  nowPaymentsInvoiceDto,
} from "./dto/nowPayments.dto";
import { NowPaymentService } from "./nowPayments.service";
import { StripeService } from "./stripe.service";
import RolesGuard from "src/guards/role.guard";
import RequestWithRawBody from "./interfaces/rawBodyRequest.interface";
import { SendGridEmailService } from "src/services/sendgridEmail.service";

@Controller("payments")
export class PaymentsController {
  constructor(
    private readonly nowpayService: NowPaymentService,
    private readonly stripeService: StripeService
  ) {}

  // Stripe Payment API Implementation
  @UseGuards(JwtAuthGuard, RolesGuard())
  @HttpCode(200)
  @Post("/stripe/createCheckoutSession")
  createCheckoutForFiat(
    @Req() req,
    @Res() res,
    @Body() body: StripeInvoiceDto
  ) {
    return this.stripeService.createCheckoutForFiat(req, res, body);
  }

  @UseGuards(JwtAuthGuard, RolesGuard())
  @HttpCode(200)
  @Post("/stripe/createCheckoutSessionFor5WF")
  createCheckoutSessionFor5WF(
    @Req() req,
    @Res() res,
    @Body() body: StripeInvoice5WFDto
  ) {
    return this.stripeService.createCheckoutSessionFor5WF(req, res, body);
  }

  @Post("/stripe/callbackNotification")
  callbackNotificationForFiat(
    @Req() req: RequestWithRawBody,
    @Headers("stripe-signature") sig: string,
    @Res() res
  ) {
    return this.stripeService.callbackNotificationForFiat(
      req.rawBody,
      sig,
      res
    );
  }

  // Now Payments API Implementation
  @UseGuards(JwtAuthGuard, RolesGuard())
  @HttpCode(200)
  @Post("/nowpayments/createInvoice")
  createInvoiceForCrypto(
    @Req() req,
    @Res() res,
    @Body() body: nowPaymentsInvoiceDto
  ) {
    return this.nowpayService.createInvoiceForCrypto(req, res, body);
  }

  @UseGuards(JwtAuthGuard, RolesGuard())
  @HttpCode(200)
  @Post("/nowpayments/createInvoiceFor5WF")
  createInvoiceFor5WF(
    @Req() req,
    @Res() res,
    @Body() body: nowPaymentsInvoice5WFDto
  ) {
    return this.nowpayService.createInvoiceFor5WF(req, res, body);
  }

  @Post("/nowpayments/callbackNotification")
  callbackNotificationForCrypto(@Req() req, @Body() body: any) {
    return this.nowpayService.callbackNotificationForCrypto(req, body);
  }

  // get equivalent currency amount to usd

  // @Cron(CronExpression.EVERY_10_HOURS)
  getLatestAmountForUSD() {
    return this.nowpayService.getLatestAmountForUSD();
  }
}
