import {
  Body,
  Controller,
  HttpStatus,
  ParseFilePipeBuilder,
  Post,
  UploadedFiles,
  UseInterceptors,
  Req,
  UseGuards,
  Get,
  HttpException,
} from "@nestjs/common";
import { CreateSpeciesDto } from "./dto/createSpecies.dto";
import { SpeciesService } from "./species.service";
import {
  FileFieldsInterceptor,
} from "@nestjs/platform-express";
import { imageValidation } from "../services/filesValidation";
import { JwtAuthGuard } from "src/guards/jwt.guard";

@Controller("species")
export class SpeciesController {
  constructor(private readonly speciesService: SpeciesService) {}

  @UseGuards(JwtAuthGuard)
  @Post("/createSpecies")
  @UseInterceptors(
    FileFieldsInterceptor(
      [
        { name: "coverImage", maxCount: 1 },
        { name: "speciesVideo", maxCount: 1 },
        { name: "speciesProfile", maxCount: 1 },
        { name: "images", maxCount: 8 },
      ],
      imageValidation
    )
  )
  async createSpeciesController(
    @UploadedFiles(
      new ParseFilePipeBuilder().build({
        errorHttpStatusCode: HttpStatus.UNPROCESSABLE_ENTITY,
      })
    )
    files: {
      coverImage?: Express.Multer.File[];
      images?: Express.Multer.File[];
      speciesProfile?: Express.Multer.File[];
      speciesVideo?: Express.Multer.File[];
    },
    @Body() body: CreateSpeciesDto,
    @Req() req
  ) {

    console.log(req.files.images);
    
    if (req.files.images) {
      if (req.files.images.length > 8) {
        throw new HttpException(
          "Only 8 images upload!",
          HttpStatus.BAD_REQUEST
        )
      }
    }

    return this.speciesService.createSpecies(
      {
        ...body,
        coverImage: req.files.coverImage,
        images: req.files.images,
        speciesProfile: req.files.speciesProfile,
        speciesVideo: req.files.speciesVideo,
      },
      req
    );
  }

  // @Patch("/speciesProfile")
  // @UseInterceptors(FileInterceptor("speciesProfile", imageValidation))
  // uploadProfileImage(
  //   @UploadedFile(
  //     new ParseFilePipeBuilder()
  //       .addMaxSizeValidator({ maxSize: 100000 })
  //       .build({ errorHttpStatusCode: HttpStatus.UNPROCESSABLE_ENTITY })
  //   )
  //   file: Express.Multer.File,
  //   @Query("id") id: string,
  //   @Request() req
  // ) {
  //   return this.speciesService.uploadSpeciesProfile(file, id, req);
  // }

  @UseGuards(JwtAuthGuard)
  @Get("/getSpecies")
  async getAllSpecies(
    @Req() req
  ) {
    return this.speciesService.getAllSpecies(req)
  }
}
