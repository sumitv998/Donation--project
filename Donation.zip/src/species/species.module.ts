import { Module } from '@nestjs/common';
import { SpeciesService } from './species.service';
import { SpeciesController } from './species.controller';
import { S3Service } from 'src/services/s3.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Species } from './entities/species.entity';
import { AssetSpecies } from './entities/assetsSpecies.entity';
import { JwtModule } from '@nestjs/jwt';

@Module({
  imports: [
    JwtModule.register({
      secret: process.env.ADMIN_JWT_SECRET,
      signOptions: {
        expiresIn: "24h",
      },
    }),
    TypeOrmModule.forFeature([Species,AssetSpecies]),
  ],
  controllers: [SpeciesController],
  providers: [SpeciesService,S3Service]
})
export class SpeciesModule {}
