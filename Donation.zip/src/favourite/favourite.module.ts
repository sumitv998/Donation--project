import { Module } from "@nestjs/common";
import { FavoriteController } from "./favourite.controller";

@Module({
  controllers: [FavoriteController],
})
export class FavouriteModule {}
