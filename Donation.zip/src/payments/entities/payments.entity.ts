import { ApiProperty } from "@nestjs/swagger";
import { IsDecimal, IsNumber, IsString } from "class-validator";
import { Projects } from "src/projects/entities/project.entity";
import { Species } from "src/species/entities/species.entity";
import { UsersCorporates } from "src/users/entities/usersCorporate.entity";
import {
  Column,
  CreateDateColumn,
  Double,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from "typeorm";

export enum STATUS {
  PENDING = "Pending",
  SUCCESS = "Success",
  REFUNDED = "Refunded",
  FAILED = "Failed",
  EXPIRED = "Expired",
  COMPLETED = "Completed",
  UNEXPECTED = "Unexpected",
}
@Entity()
export class paymentTransactions {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @ApiProperty()
  @Column({ nullable: true })
  @IsString()
  invoiceId: string;

  @ApiProperty()
  @ManyToOne(() => Species, (species: Species) => species.speciesTransaction)
  @JoinColumn({ name: "speciesId" })
  species: Species;

  @ApiProperty()
  @ManyToOne(() => Projects, (project: Projects) => project.projectTransaction)
  @JoinColumn({ name: "projectId" })
  project: Projects;

  @ManyToOne(
    () => UsersCorporates,
    (users: UsersCorporates) => users.userTransaction
  )
  @JoinColumn({ name: "userId" })
  user: UsersCorporates;

  @ApiProperty()
  @Column({ default: false, nullable: true })
  @IsString()
  is5WF: boolean;

  @ApiProperty()
  @Column({ nullable: true })
  @IsString()
  currency: string;

  @ApiProperty()
  @Column({ nullable: true })
  @IsString()
  paidCurrency: string;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  @IsDecimal()
  paidAmount: Double;

  @ApiProperty()
  @Column({ type: "double precision", default: 0, nullable: true })
  @IsDecimal()
  amount: Double;

  @ApiProperty()
  @Column({ default: STATUS.PENDING })
  @IsString()
  status: STATUS;

  @ApiProperty()
  @CreateDateColumn()
  createdAt: Date;

  @ApiProperty()
  @UpdateDateColumn()
  updatedAt: Date;
}
