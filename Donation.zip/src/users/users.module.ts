import { Module } from "@nestjs/common";
import { UsersService } from "./users.service";
import { UsersController } from "./users.controller";
import { TypeOrmModule } from "@nestjs/typeorm";
import { UsersCorporates } from "./entities/usersCorporate.entity";
import { JwtService } from "@nestjs/jwt";
import { favouriteSpecies } from "src/favourite/entities/favSpecies.entity";
import { Species } from "src/species/entities/species.entity";
import { favouriteProject } from "src/favourite/entities/favProjects.entity";
import { Projects } from "src/projects/entities/project.entity";
import { SendGridEmailService } from "src/services/sendgridEmail.service";
import { JwtStrategy } from "src/guards/jwt.strategy";
import { S3Service } from "src/services/s3.service";
import { responseValidation } from "src/services/responseHandler";
import { paymentTransactions } from "src/payments/entities/payments.entity";
import { mailFormat } from "src/config/mailFormat";
import { Countries } from "src/config/countries";
import { kycDetails } from "src/kyc/entities/companyInfo.entity";
// import { ErrorHandling } from "src/config/constants";

@Module({
  imports: [
    TypeOrmModule.forFeature([
      UsersCorporates,
      favouriteSpecies,
      favouriteProject,
      Species,
      Projects,
      paymentTransactions,
      kycDetails,
    ]),
  ],
  controllers: [UsersController],
  providers: [
    UsersService,
    JwtService,
    SendGridEmailService,
    JwtStrategy,
    S3Service,
    responseValidation,
    mailFormat,
    Countries,
  ],
})
export class UsersModule {}
